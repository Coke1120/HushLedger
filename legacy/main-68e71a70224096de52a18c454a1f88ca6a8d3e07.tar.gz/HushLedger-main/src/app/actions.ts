'use server'

import { revalidatePath } from 'next/cache'
import {
  accountCreateSchema,
  accountRegisterClearingSchema,
  accountTransferDeleteSchema,
  accountTransferInputSchema,
  accountTransferUpdateSchema,
  accountUpdateSchema,
  categoryCreateSchema,
  categoryUpdateSchema,
  referenceIdSchema,
  referenceOrderSchema,
  referenceStatusSchema,
  recurringRuleCreateSchema,
  recurringRuleDeleteSchema,
  recurringRuleSkipSchema,
  recurringRuleStatusSchema,
  recurringRuleUpdateSchema,
  recurringTransferRuleCreateSchema,
  recurringTransferRuleDeleteSchema,
  recurringTransferRuleIdSchema,
  recurringTransferRuleSkipSchema,
  recurringTransferRuleStatusSchema,
  recurringTransferRuleUpdateSchema,
  transactionDeleteSchema,
  transactionCategoryBatchSchema,
  transactionClearingBatchSchema,
  transactionIdSchema,
  transactionInputSchema,
  transactionImportReviewBatchSchema,
  transactionUpdateSchema,
  type RecurringGenerationResult,
  type RecurringTransferGenerationResult,
  type Account,
  type AccountTransfer,
  type Category,
  type ImportReviewStatus,
} from '../lib/schema'
import {
  actionError,
  actionSuccess,
  type ActionResult,
} from '../server/action-result'
import { isServerActionAllowed } from '../server/auth'
import { getDatabase } from '../server/db'
import { sanitizeValidationIssues } from '../server/http'
import {
  setAccountRegisterEntryClearing,
  type SetAccountRegisterEntryClearingResult,
} from '../server/accountRegister'
import {
  createTransaction,
  deleteTransaction,
  setTransactionsCategory,
  setTransactionsClearing,
  setTransactionsImportReviewStatus,
  updateTransaction,
  type TransactionView,
  type UpdateTransactionResult,
} from '../server/money'
import {
  createAccountReference,
  createCategoryReference,
  reorderAccountReferences,
  reorderCategoryReferences,
  setAccountReferenceStatus,
  setCategoryReferenceStatus,
  updateAccountReference,
  updateCategoryReference,
  type ReferenceMutationResult,
  type ReferenceOrderResult,
} from '../server/referenceData'
import {
  createRecurringRule,
  deleteRecurringRule,
  runDueRecurringRules,
  setRecurringRuleStatus,
  skipRecurringRuleOccurrence,
  updateRecurringRule,
  type RecurringRuleView,
  type ReferenceErrorCode,
  type UpdateRuleResult,
} from '../server/recurring'
import {
  createRecurringTransferRule,
  deleteRecurringTransferRule,
  runDueRecurringTransferRules,
  setRecurringTransferRuleStatus,
  skipRecurringTransferRuleOccurrence,
  updateRecurringTransferRule,
  type RecurringTransferReferenceErrorCode,
  type RecurringTransferRuleView,
  type UpdateRecurringTransferRuleResult,
} from '../server/recurringTransfers'
import {
  createAccountTransfer,
  deleteAccountTransfer,
  updateAccountTransfer,
  type UpdateAccountTransferResult,
} from '../server/transfers'
import { emptyActionSchema, recurringRuleIdSchema } from '../server/validation'

type DeletedRule = { id: string; deleted: true; revision: number }
type DeletedTransaction = { id: string; deleted: true }
type DeletedTransfer = { id: string; deleted: true }

export async function createAccountAction(input: unknown): Promise<ActionResult<Account>> {
  const denied = await accessDenied<Account>()
  if (denied) return denied

  const parsed = accountCreateSchema.safeParse(input)
  if (!parsed.success) return validationError('帳戶資料不正確', parsed.error.issues)

  return runAction('create_account', async () => referenceMutationResult(
    await createAccountReference(await getDatabase(), parsed.data),
  ))
}

export async function updateAccountAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<Account>> {
  const denied = await accessDenied<Account>()
  if (denied) return denied

  const id = referenceIdSchema.safeParse(idInput)
  if (!id.success) return invalidReferenceId(id.error.issues)
  const parsed = accountUpdateSchema.safeParse(input)
  if (!parsed.success) return validationError('帳戶資料不正確', parsed.error.issues)

  return runAction('update_account', async () => referenceMutationResult(
    await updateAccountReference(await getDatabase(), id.data, parsed.data),
  ))
}

export async function setAccountStatusAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<Account>> {
  const denied = await accessDenied<Account>()
  if (denied) return denied

  const id = referenceIdSchema.safeParse(idInput)
  if (!id.success) return invalidReferenceId(id.error.issues)
  const parsed = referenceStatusSchema.safeParse(input)
  if (!parsed.success) return validationError('帳戶狀態不正確', parsed.error.issues)

  return runAction('set_account_status', async () => referenceMutationResult(
    await setAccountReferenceStatus(await getDatabase(), id.data, parsed.data),
  ))
}

export async function reorderAccountsAction(input: unknown): Promise<ActionResult<Account[]>> {
  const denied = await accessDenied<Account[]>()
  if (denied) return denied

  const parsed = referenceOrderSchema.safeParse(input)
  if (!parsed.success) return validationError('帳戶排序資料不正確', parsed.error.issues)

  return runAction('reorder_accounts', async () => referenceOrderResult(
    await reorderAccountReferences(await getDatabase(), parsed.data),
  ))
}

export async function createCategoryAction(input: unknown): Promise<ActionResult<Category>> {
  const denied = await accessDenied<Category>()
  if (denied) return denied

  const parsed = categoryCreateSchema.safeParse(input)
  if (!parsed.success) return validationError('分類資料不正確', parsed.error.issues)

  return runAction('create_category', async () => referenceMutationResult(
    await createCategoryReference(await getDatabase(), parsed.data),
  ))
}

export async function updateCategoryAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<Category>> {
  const denied = await accessDenied<Category>()
  if (denied) return denied

  const id = referenceIdSchema.safeParse(idInput)
  if (!id.success) return invalidReferenceId(id.error.issues)
  const parsed = categoryUpdateSchema.safeParse(input)
  if (!parsed.success) return validationError('分類資料不正確', parsed.error.issues)

  return runAction('update_category', async () => referenceMutationResult(
    await updateCategoryReference(await getDatabase(), id.data, parsed.data),
  ))
}

export async function setCategoryStatusAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<Category>> {
  const denied = await accessDenied<Category>()
  if (denied) return denied

  const id = referenceIdSchema.safeParse(idInput)
  if (!id.success) return invalidReferenceId(id.error.issues)
  const parsed = referenceStatusSchema.safeParse(input)
  if (!parsed.success) return validationError('分類狀態不正確', parsed.error.issues)

  return runAction('set_category_status', async () => referenceMutationResult(
    await setCategoryReferenceStatus(await getDatabase(), id.data, parsed.data),
  ))
}

export async function reorderCategoriesAction(input: unknown): Promise<ActionResult<Category[]>> {
  const denied = await accessDenied<Category[]>()
  if (denied) return denied

  const parsed = referenceOrderSchema.safeParse(input)
  if (!parsed.success) return validationError('分類排序資料不正確', parsed.error.issues)

  return runAction('reorder_categories', async () => referenceOrderResult(
    await reorderCategoryReferences(await getDatabase(), parsed.data),
  ))
}

export async function createTransactionAction(
  input: unknown,
): Promise<ActionResult<TransactionView>> {
  const denied = await accessDenied<TransactionView>()
  if (denied) return denied

  const parsed = transactionInputSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('交易資料不正確', parsed.error.issues)
  }

  return runAction('create_transaction', async () => {
    const result = await createTransaction(await getDatabase(), parsed.data)
    if (result.kind === 'id_conflict') {
      return actionError('ID_CONFLICT', '交易 ID 已用於另一筆資料')
    }
    if (result.kind === 'reference_invalid') return referenceError(result.code)
    return revalidatedSuccess(result.transaction)
  })
}

export async function updateTransactionAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<TransactionView>> {
  const denied = await accessDenied<TransactionView>()
  if (denied) return denied

  const id = transactionIdSchema.safeParse(idInput)
  if (!id.success) return invalidTransactionId(id.error.issues)

  const parsed = transactionUpdateSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('交易資料不正確', parsed.error.issues)
  }

  return runAction('update_transaction', async () => {
    const result = await updateTransaction(await getDatabase(), id.data, parsed.data)
    return transactionMutationResult(result)
  })
}

export async function deleteTransactionAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<DeletedTransaction>> {
  const denied = await accessDenied<DeletedTransaction>()
  if (denied) return denied

  const id = transactionIdSchema.safeParse(idInput)
  if (!id.success) return invalidTransactionId(id.error.issues)

  const parsed = transactionDeleteSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('刪除交易資料不正確', parsed.error.issues)
  }

  return runAction('delete_transaction', async () => {
    const result = await deleteTransaction(await getDatabase(), id.data, parsed.data.updatedAt)
    if (result.kind === 'not_found') {
      return actionError('TRANSACTION_NOT_FOUND', '找不到指定的交易')
    }
    if (result.kind === 'version_conflict') {
      return actionError('TRANSACTION_VERSION_CONFLICT', '交易已被修改，請重新載入後再試')
    }
    return revalidatedSuccess({ id: result.id, deleted: true })
  })
}

export async function setTransactionsClearingAction(
  input: unknown,
): Promise<ActionResult<{ updated: number; cleared: boolean }>> {
  const denied = await accessDenied<{ updated: number; cleared: boolean }>()
  if (denied) return denied

  const parsed = transactionClearingBatchSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('批次交易狀態資料不正確', parsed.error.issues)
  }

  return runAction('set_transactions_clearing', async () => {
    const result = await setTransactionsClearing(await getDatabase(), parsed.data)
    if (result.kind === 'version_conflict') {
      return actionError('TRANSACTION_VERSION_CONFLICT', '交易已被修改，請重新載入後再試')
    }
    return revalidatedSuccess({ updated: result.count, cleared: parsed.data.cleared })
  })
}

export async function setTransactionsImportReviewStatusAction(
  input: unknown,
): Promise<ActionResult<{ updated: number; status: ImportReviewStatus }>> {
  const denied = await accessDenied<{ updated: number; status: ImportReviewStatus }>()
  if (denied) return denied

  const parsed = transactionImportReviewBatchSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('匯入交易審查資料不正確', parsed.error.issues)
  }

  return runAction('set_transactions_import_review_status', async () => {
    const result = await setTransactionsImportReviewStatus(await getDatabase(), parsed.data)
    if (result.kind === 'version_conflict') {
      return actionError('TRANSACTION_VERSION_CONFLICT', '交易已被修改，請重新載入後再試')
    }
    return revalidatedSuccess({ updated: result.count, status: parsed.data.status })
  })
}

export async function setAccountRegisterEntryClearingAction(
  input: unknown,
): Promise<ActionResult<{ id: string; updatedAt: string; cleared: boolean }>> {
  const denied = await accessDenied<{ id: string; updatedAt: string; cleared: boolean }>()
  if (denied) return denied

  const parsed = accountRegisterClearingSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('流水帳清算狀態資料不正確', parsed.error.issues)
  }

  return runAction('set_account_register_entry_clearing', async () =>
    accountRegisterClearingResult(
      await setAccountRegisterEntryClearing(await getDatabase(), parsed.data),
    ),
  )
}

export async function setTransactionsCategoryAction(
  input: unknown,
): Promise<ActionResult<{ updated: number; categoryId: number }>> {
  const denied = await accessDenied<{ updated: number; categoryId: number }>()
  if (denied) return denied

  const parsed = transactionCategoryBatchSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('批次交易分類資料不正確', parsed.error.issues)
  }

  return runAction('set_transactions_category', async () => {
    const result = await setTransactionsCategory(await getDatabase(), parsed.data)
    if (result.kind === 'version_conflict') {
      return actionError('TRANSACTION_VERSION_CONFLICT', '交易已被修改，請重新載入後再試')
    }
    if (result.kind === 'reference_invalid') return referenceError(result.code)
    return revalidatedSuccess({ updated: result.count, categoryId: parsed.data.categoryId })
  })
}

export async function createAccountTransferAction(
  input: unknown,
): Promise<ActionResult<AccountTransfer>> {
  const denied = await accessDenied<AccountTransfer>()
  if (denied) return denied

  const parsed = accountTransferInputSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('帳戶轉帳資料不正確', parsed.error.issues)
  }

  return runAction('create_account_transfer', async () => {
    const result = await createAccountTransfer(await getDatabase(), parsed.data)
    if (result.kind === 'id_conflict') {
      return actionError('ID_CONFLICT', '帳戶轉帳 ID 已用於另一筆資料')
    }
    if (result.kind === 'reference_invalid') return referenceError('ACCOUNT_INVALID')
    return revalidatedSuccess(result.transfer)
  })
}

export async function updateAccountTransferAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<AccountTransfer>> {
  const denied = await accessDenied<AccountTransfer>()
  if (denied) return denied

  const id = transactionIdSchema.safeParse(idInput)
  if (!id.success) return invalidTransferId(id.error.issues)

  const parsed = accountTransferUpdateSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('帳戶轉帳資料不正確', parsed.error.issues)
  }

  return runAction('update_account_transfer', async () => transferMutationResult(
    await updateAccountTransfer(await getDatabase(), id.data, parsed.data),
  ))
}

export async function deleteAccountTransferAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<DeletedTransfer>> {
  const denied = await accessDenied<DeletedTransfer>()
  if (denied) return denied

  const id = transactionIdSchema.safeParse(idInput)
  if (!id.success) return invalidTransferId(id.error.issues)

  const parsed = accountTransferDeleteSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('刪除帳戶轉帳資料不正確', parsed.error.issues)
  }

  return runAction('delete_account_transfer', async () => {
    const result = await deleteAccountTransfer(await getDatabase(), id.data, parsed.data.updatedAt)
    if (result.kind === 'not_found') {
      return actionError('TRANSFER_NOT_FOUND', '找不到指定的帳戶轉帳')
    }
    if (result.kind === 'version_conflict') {
      return actionError('TRANSFER_VERSION_CONFLICT', '帳戶轉帳已被修改，請重新載入後再試')
    }
    return revalidatedSuccess({ id: result.id, deleted: true })
  })
}

export async function createRecurringRuleAction(
  input: unknown,
): Promise<ActionResult<RecurringRuleView>> {
  const denied = await accessDenied<RecurringRuleView>()
  if (denied) return denied

  const parsed = recurringRuleCreateSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期交易資料不正確', parsed.error.issues)
  }

  return runAction('create_recurring_rule', async () => {
    const result = await createRecurringRule(await getDatabase(), parsed.data)
    if (result.kind === 'id_conflict') {
      return actionError('ID_CONFLICT', '週期交易 ID 已用於另一筆資料')
    }
    if (result.kind === 'reference_invalid') return referenceError(result.code)
    return revalidatedSuccess(result.rule)
  })
}

export async function updateRecurringRuleAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<RecurringRuleView>> {
  const denied = await accessDenied<RecurringRuleView>()
  if (denied) return denied

  const id = recurringRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRuleId(id.error.issues)

  const parsed = recurringRuleUpdateSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期交易資料不正確', parsed.error.issues)
  }

  return runAction('update_recurring_rule', async () => {
    const result = await updateRecurringRule(await getDatabase(), id.data, parsed.data)
    return recurringMutationResult(result)
  })
}

export async function setRecurringRuleStatusAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<RecurringRuleView>> {
  const denied = await accessDenied<RecurringRuleView>()
  if (denied) return denied

  const id = recurringRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRuleId(id.error.issues)

  const parsed = recurringRuleStatusSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期交易狀態不正確', parsed.error.issues)
  }

  return runAction('set_recurring_rule_status', async () => {
    const result = await setRecurringRuleStatus(await getDatabase(), id.data, parsed.data)
    return recurringMutationResult(result)
  })
}

export async function skipRecurringRuleOccurrenceAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<RecurringRuleView>> {
  const denied = await accessDenied<RecurringRuleView>()
  if (denied) return denied

  const id = recurringRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRuleId(id.error.issues)

  const parsed = recurringRuleSkipSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('略過週期交易資料不正確', parsed.error.issues)
  }

  return runAction('skip_recurring_rule_occurrence', async () => {
    const result = await skipRecurringRuleOccurrence(await getDatabase(), id.data, parsed.data)
    return recurringMutationResult(result)
  })
}

export async function deleteRecurringRuleAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<DeletedRule>> {
  const denied = await accessDenied<DeletedRule>()
  if (denied) return denied

  const id = recurringRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRuleId(id.error.issues)

  const parsed = recurringRuleDeleteSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('刪除週期交易資料不正確', parsed.error.issues)
  }

  return runAction('delete_recurring_rule', async () => {
    const result = await deleteRecurringRule(await getDatabase(), id.data, parsed.data.revision)
    if (result.kind === 'not_found') {
      return actionError('RULE_NOT_FOUND', '找不到指定的週期交易')
    }
    if (result.kind === 'version_conflict') {
      return actionError('RULE_VERSION_CONFLICT', '週期交易已被修改，請重新載入後再試')
    }
    return revalidatedSuccess({ id: result.id, deleted: true, revision: result.revision })
  })
}

export async function runDueRecurringRulesAction(
  input: unknown = {},
): Promise<ActionResult<RecurringGenerationResult>> {
  const denied = await accessDenied<RecurringGenerationResult>()
  if (denied) return denied

  const parsed = emptyActionSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期交易執行資料不正確', parsed.error.issues)
  }

  return runAction('run_due_recurring_rules', async () => {
    const result = await runDueRecurringRules(await getDatabase())
    return revalidatedSuccess(result)
  })
}

export async function createRecurringTransferRuleAction(
  input: unknown,
): Promise<ActionResult<RecurringTransferRuleView>> {
  const denied = await accessDenied<RecurringTransferRuleView>()
  if (denied) return denied

  const parsed = recurringTransferRuleCreateSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期轉帳資料不正確', parsed.error.issues)
  }

  return runAction('create_recurring_transfer_rule', async () => {
    const result = await createRecurringTransferRule(await getDatabase(), parsed.data)
    if (result.kind === 'id_conflict') {
      return actionError('ID_CONFLICT', '週期轉帳 ID 已用於另一筆資料')
    }
    if (result.kind === 'reference_invalid') {
      return recurringTransferReferenceError(result.code)
    }
    return revalidatedSuccess(result.rule)
  })
}

export async function updateRecurringTransferRuleAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<RecurringTransferRuleView>> {
  const denied = await accessDenied<RecurringTransferRuleView>()
  if (denied) return denied

  const id = recurringTransferRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRecurringTransferRuleId(id.error.issues)

  const parsed = recurringTransferRuleUpdateSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期轉帳資料不正確', parsed.error.issues)
  }

  return runAction('update_recurring_transfer_rule', async () =>
    recurringTransferMutationResult(
      await updateRecurringTransferRule(await getDatabase(), id.data, parsed.data),
    ),
  )
}

export async function setRecurringTransferRuleStatusAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<RecurringTransferRuleView>> {
  const denied = await accessDenied<RecurringTransferRuleView>()
  if (denied) return denied

  const id = recurringTransferRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRecurringTransferRuleId(id.error.issues)

  const parsed = recurringTransferRuleStatusSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期轉帳狀態不正確', parsed.error.issues)
  }

  return runAction('set_recurring_transfer_rule_status', async () =>
    recurringTransferMutationResult(
      await setRecurringTransferRuleStatus(await getDatabase(), id.data, parsed.data),
    ),
  )
}

export async function skipRecurringTransferRuleOccurrenceAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<RecurringTransferRuleView>> {
  const denied = await accessDenied<RecurringTransferRuleView>()
  if (denied) return denied

  const id = recurringTransferRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRecurringTransferRuleId(id.error.issues)

  const parsed = recurringTransferRuleSkipSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('略過週期轉帳資料不正確', parsed.error.issues)
  }

  return runAction('skip_recurring_transfer_rule_occurrence', async () =>
    recurringTransferMutationResult(
      await skipRecurringTransferRuleOccurrence(await getDatabase(), id.data, parsed.data),
    ),
  )
}

export async function deleteRecurringTransferRuleAction(
  idInput: unknown,
  input: unknown,
): Promise<ActionResult<DeletedRule>> {
  const denied = await accessDenied<DeletedRule>()
  if (denied) return denied

  const id = recurringTransferRuleIdSchema.safeParse(idInput)
  if (!id.success) return invalidRecurringTransferRuleId(id.error.issues)

  const parsed = recurringTransferRuleDeleteSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('刪除週期轉帳資料不正確', parsed.error.issues)
  }

  return runAction('delete_recurring_transfer_rule', async () => {
    const result = await deleteRecurringTransferRule(
      await getDatabase(),
      id.data,
      parsed.data.revision,
    )
    if (result.kind === 'not_found') {
      return actionError('RECURRING_TRANSFER_RULE_NOT_FOUND', '找不到指定的週期轉帳')
    }
    if (result.kind === 'version_conflict') {
      return actionError(
        'RECURRING_TRANSFER_RULE_VERSION_CONFLICT',
        '週期轉帳已被修改，請重新載入後再試',
      )
    }
    return revalidatedSuccess({ id: result.id, deleted: true, revision: result.revision })
  })
}

export async function runDueRecurringTransferRulesAction(
  input: unknown = {},
): Promise<ActionResult<RecurringTransferGenerationResult>> {
  const denied = await accessDenied<RecurringTransferGenerationResult>()
  if (denied) return denied

  const parsed = emptyActionSchema.safeParse(input)
  if (!parsed.success) {
    return validationError('週期轉帳執行資料不正確', parsed.error.issues)
  }

  return runAction('run_due_recurring_transfer_rules', async () => {
    const result = await runDueRecurringTransferRules(await getDatabase())
    return revalidatedSuccess(result)
  })
}

async function runAction<T>(
  name: string,
  operation: () => Promise<ActionResult<T>>,
): Promise<ActionResult<T>> {
  try {
    return await operation()
  } catch {
    console.error('server_action_failed', { action: name })
    return actionError('INTERNAL_ERROR', '伺服器暫時無法處理請求')
  }
}

function revalidatedSuccess<T>(data: T): ActionResult<T> {
  revalidatePath('/')
  return actionSuccess(data)
}

function validationError<T>(message: string, issues: Parameters<typeof sanitizeValidationIssues>[0]) {
  return actionError<T>('VALIDATION_ERROR', message, sanitizeValidationIssues(issues))
}

function invalidRuleId<T>(issues: Parameters<typeof sanitizeValidationIssues>[0]) {
  return actionError<T>(
    'INVALID_RULE_ID',
    '週期交易 ID 不正確',
    sanitizeValidationIssues(issues),
  )
}

function invalidRecurringTransferRuleId<T>(
  issues: Parameters<typeof sanitizeValidationIssues>[0],
) {
  return actionError<T>(
    'INVALID_RULE_ID',
    '週期轉帳 ID 不正確',
    sanitizeValidationIssues(issues),
  )
}

function invalidTransactionId<T>(issues: Parameters<typeof sanitizeValidationIssues>[0]) {
  return actionError<T>(
    'INVALID_TRANSACTION_ID',
    '交易 ID 不正確',
    sanitizeValidationIssues(issues),
  )
}

function invalidTransferId<T>(issues: Parameters<typeof sanitizeValidationIssues>[0]) {
  return actionError<T>(
    'INVALID_TRANSFER_ID',
    '帳戶轉帳 ID 不正確',
    sanitizeValidationIssues(issues),
  )
}

function invalidReferenceId<T>(issues: Parameters<typeof sanitizeValidationIssues>[0]) {
  return actionError<T>(
    'INVALID_REFERENCE_ID',
    '帳戶或分類 ID 不正確',
    sanitizeValidationIssues(issues),
  )
}

function referenceMutationResult<T>(result: ReferenceMutationResult<T>): ActionResult<T> {
  if (result.kind === 'created' || result.kind === 'updated') {
    return revalidatedSuccess(result.item)
  }
  if (result.kind === 'not_found') {
    return actionError('REFERENCE_NOT_FOUND', '找不到指定的帳戶或分類')
  }
  if (result.kind === 'version_conflict') {
    return actionError('REFERENCE_VERSION_CONFLICT', '帳戶或分類已被修改，請重新載入後再試')
  }
  if (result.kind === 'currency_conflict') {
    return actionError('LEDGER_CURRENCY_VERSION_CONFLICT', '帳本幣別已被修改，請重新載入後再試')
  }
  if (result.kind === 'name_conflict') {
    return actionError('REFERENCE_NAME_CONFLICT', '同類型已有相同名稱')
  }
  if (result.kind === 'last_active') {
    return actionError('REFERENCE_LAST_ACTIVE', '必須保留至少一個可用項目')
  }
  if (result.kind === 'active_rules') {
    return actionError('REFERENCE_ACTIVE_RULES', '請先暫停或修改使用此項目的週期交易或排程轉帳')
  }
  if (result.kind === 'emergency_fund_goal') {
    return actionError('REFERENCE_EMERGENCY_FUND_GOAL', '請先移動或移除使用此帳戶的緊急備用金目標')
  }
  return actionError('INTERNAL_ERROR', '伺服器暫時無法處理請求')
}

function referenceOrderResult<T>(result: ReferenceOrderResult<T>): ActionResult<T[]> {
  if (result.kind === 'updated') return revalidatedSuccess(result.items)
  return actionError('REFERENCE_VERSION_CONFLICT', '帳戶或分類已被修改，請重新載入後再試')
}

function referenceError<T>(code: ReferenceErrorCode): ActionResult<T> {
  if (code === 'ACCOUNT_INVALID') {
    return actionError(code, '帳戶不存在、已停用或幣別不相符')
  }
  if (code === 'CATEGORY_INVALID') {
    return actionError(code, '分類不存在或已停用')
  }
  return actionError(code, '分類與交易類型不相符')
}

function recurringMutationResult(result: UpdateRuleResult): ActionResult<RecurringRuleView> {
  if (result.kind === 'not_found') {
    return actionError('RULE_NOT_FOUND', '找不到指定的週期交易')
  }
  if (result.kind === 'version_conflict') {
    return actionError('RULE_VERSION_CONFLICT', '週期交易已被修改，請重新載入後再試')
  }
  if (result.kind === 'reference_invalid') return referenceError(result.code)
  return revalidatedSuccess(result.rule)
}

function recurringTransferReferenceError<T>(
  code: RecurringTransferReferenceErrorCode,
): ActionResult<T> {
  return code === 'ACCOUNT_OPENING_DATE_AFTER_DUE'
    ? actionError(code, '週期轉帳日期不得早於帳戶期初結餘日期')
    : actionError(code, '帳戶不存在、已停用或幣別不相符')
}

function recurringTransferMutationResult(
  result: UpdateRecurringTransferRuleResult,
): ActionResult<RecurringTransferRuleView> {
  if (result.kind === 'not_found') {
    return actionError('RECURRING_TRANSFER_RULE_NOT_FOUND', '找不到指定的週期轉帳')
  }
  if (result.kind === 'version_conflict') {
    return actionError(
      'RECURRING_TRANSFER_RULE_VERSION_CONFLICT',
      '週期轉帳已被修改，請重新載入後再試',
    )
  }
  if (result.kind === 'reference_invalid') {
    return recurringTransferReferenceError(result.code)
  }
  return revalidatedSuccess(result.rule)
}

function transactionMutationResult(result: UpdateTransactionResult): ActionResult<TransactionView> {
  if (result.kind === 'not_found') {
    return actionError('TRANSACTION_NOT_FOUND', '找不到指定的交易')
  }
  if (result.kind === 'version_conflict') {
    return actionError('TRANSACTION_VERSION_CONFLICT', '交易已被修改，請重新載入後再試')
  }
  if (result.kind === 'reference_invalid') return referenceError(result.code)
  return revalidatedSuccess(result.transaction)
}

function accountRegisterClearingResult(
  result: SetAccountRegisterEntryClearingResult,
): ActionResult<{ id: string; updatedAt: string; cleared: boolean }> {
  if (result.kind === 'not_found') {
    return actionError('REGISTER_ENTRY_NOT_FOUND', '找不到指定的流水帳項目')
  }
  if (result.kind === 'version_conflict') {
    return actionError('REGISTER_ENTRY_VERSION_CONFLICT', '流水帳項目已被修改，請重新載入後再試')
  }
  if (result.kind === 'account_mismatch') {
    return actionError('REGISTER_ENTRY_ACCOUNT_MISMATCH', '流水帳項目不屬於指定帳戶')
  }
  return revalidatedSuccess({
    id: result.id,
    updatedAt: result.updatedAt,
    cleared: result.cleared,
  })
}

function transferMutationResult(result: UpdateAccountTransferResult): ActionResult<AccountTransfer> {
  if (result.kind === 'not_found') {
    return actionError('TRANSFER_NOT_FOUND', '找不到指定的帳戶轉帳')
  }
  if (result.kind === 'version_conflict') {
    return actionError('TRANSFER_VERSION_CONFLICT', '帳戶轉帳已被修改，請重新載入後再試')
  }
  if (result.kind === 'reference_invalid') return referenceError('ACCOUNT_INVALID')
  return revalidatedSuccess(result.transfer)
}

async function accessDenied<T>() {
  return (await isServerActionAllowed())
    ? null
    : actionError<T>('ACCESS_FORBIDDEN', '無法驗證存取權限')
}
