import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import {
  accountCreateSchema,
  accountTransferInputSchema,
  accountTransferQuerySchema,
  accountTransferUpdateSchema,
  accountUpdateSchema,
  categoryCreateSchema,
  categoryUpdateSchema,
  emergencyFundGoalDeleteSchema,
  emergencyFundGoalSaveSchema,
  importReviewStatusSchema,
  referenceIdSchema,
  referenceOrderSchema,
  referenceStatusSchema,
  recurringRuleCreateSchema,
  recurringRuleDeleteSchema,
  recurringRuleSkipSchema,
  recurringRuleStatusSchema,
  recurringRuleUpdateSchema,
  recurringTransferRuleCreateSchema,
  recurringTransferRuleDeleteSchema,
  recurringTransferRuleSkipSchema,
  recurringTransferRuleStatusSchema,
  recurringTransferRuleUpdateSchema,
  transactionDeleteSchema,
  transactionCategoryBatchSchema,
  transactionClearingBatchSchema,
  transactionDuplicateCheckSchema,
  transactionInputSchema,
  transactionImportReviewBatchSchema,
  transactionPageQuerySchema,
  transactionQuerySchema,
  transactionUpdateSchema,
} from './schema'

describe('reference data validation', () => {
  const updatedAt = '2026-07-11T10:30:00.000Z'

  it('accepts strict account and category mutations', () => {
    assert.deepEqual(accountCreateSchema.parse({ name: 'Savings', type: 'bank', currency: 'USD' }), {
      name: 'Savings',
      type: 'bank',
      currency: 'USD',
      expectedCurrency: 'HKD',
      openingBalanceMinor: null,
      openingBalanceOn: null,
    })
    assert.equal(accountUpdateSchema.safeParse({
      name: 'Cash',
      type: 'cash',
      openingBalanceMinor: -12_345,
      openingBalanceOn: '2026-07-01',
      updatedAt,
    }).success, true)
    assert.deepEqual(categoryCreateSchema.parse({
      name: 'Education',
      type: 'expense',
      monthlyPlanMinor: 25_000,
    }), {
      name: 'Education',
      type: 'expense',
      expectedCurrency: 'HKD',
      monthlyPlanMinor: 25_000,
    })
    assert.deepEqual(categoryCreateSchema.parse({ name: 'Gift', type: 'income' }), {
      name: 'Gift',
      type: 'income',
      expectedCurrency: 'HKD',
      monthlyPlanMinor: null,
    })
    assert.equal(categoryUpdateSchema.safeParse({
      name: 'Books',
      type: 'expense',
      monthlyPlanMinor: null,
      updatedAt,
    }).success, true)
    assert.equal(referenceStatusSchema.safeParse({ isActive: false, updatedAt }).success, true)
    assert.equal(referenceOrderSchema.safeParse({
      items: [{ id: 2, updatedAt }, { id: 1, updatedAt }],
    }).success, true)
    assert.equal(referenceIdSchema.parse('42'), 42)
  })

  it('rejects empty names, unknown types, and extra fields', () => {
    assert.equal(accountCreateSchema.safeParse({ name: ' ', type: 'bank', currency: 'HKD' }).success, false)
    assert.equal(accountCreateSchema.safeParse({ name: 'Card', type: 'loan', currency: 'HKD' }).success, false)
    assert.equal(accountCreateSchema.safeParse({
      name: 'Card',
      type: 'credit_card',
      currency: 'JPY',
    }).success, false)
    assert.equal(accountCreateSchema.safeParse({
      name: 'Card',
      type: 'credit_card',
      openingBalanceMinor: -10_000,
    }).success, false)
    assert.equal(accountUpdateSchema.safeParse({
      name: 'Cash',
      type: 'cash',
      openingBalanceMinor: null,
      openingBalanceOn: '2026-07-01',
      updatedAt,
    }).success, false)
    assert.equal(categoryCreateSchema.safeParse({ name: 'Food', type: 'transfer' }).success, false)
    assert.equal(
      categoryCreateSchema.safeParse({
        name: 'Salary',
        type: 'income',
        monthlyPlanMinor: 100_000,
      }).success,
      false,
    )
    assert.equal(
      categoryUpdateSchema.safeParse({
        name: 'Salary',
        type: 'income',
        monthlyPlanMinor: 100_000,
        updatedAt,
      }).success,
      false,
    )
    assert.equal(
      categoryUpdateSchema.safeParse({
        name: 'Food',
        type: 'expense',
        monthlyPlanMinor: Number.MAX_SAFE_INTEGER + 1,
        updatedAt,
      }).success,
      false,
    )
    assert.equal(
      categoryUpdateSchema.safeParse({ name: 'Food', monthlyPlanMinor: null, updatedAt }).success,
      false,
    )
    assert.equal(referenceOrderSchema.safeParse({ items: [{ id: 1, updatedAt }] }).success, false)
    assert.equal(referenceOrderSchema.safeParse({
      items: [{ id: 1, updatedAt }, { id: 1, updatedAt }],
    }).success, false)
    assert.equal(referenceOrderSchema.safeParse({
      items: [{ id: 1, updatedAt }, { id: 2, updatedAt, sortOrder: 20 }],
    }).success, false)
  })
})

describe('emergency fund goal validation', () => {
  const updatedAt = '2026-07-13T10:30:00.000Z'

  it('accepts strict create, update, and delete versions', () => {
    assert.deepEqual(emergencyFundGoalSaveSchema.parse({
      accountId: 2,
      targetMinor: 500_000,
      expectedUpdatedAt: null,
    }), {
      accountId: 2,
      targetMinor: 500_000,
      expectedCurrency: 'HKD',
      expectedUpdatedAt: null,
    })
    assert.equal(emergencyFundGoalSaveSchema.safeParse({
      accountId: 2,
      targetMinor: 600_000,
      expectedUpdatedAt: updatedAt,
    }).success, true)
    assert.deepEqual(emergencyFundGoalDeleteSchema.parse({ expectedUpdatedAt: updatedAt }), {
      expectedUpdatedAt: updatedAt,
    })
  })

  it('rejects unsafe targets, missing versions, and extra fields', () => {
    assert.equal(emergencyFundGoalSaveSchema.safeParse({
      accountId: 2,
      targetMinor: 0,
      expectedUpdatedAt: null,
    }).success, false)
    assert.equal(emergencyFundGoalSaveSchema.safeParse({
      accountId: 2,
      targetMinor: Number.MAX_SAFE_INTEGER + 1,
      expectedUpdatedAt: null,
    }).success, false)
    assert.equal(emergencyFundGoalSaveSchema.safeParse({
      accountId: 2,
      targetMinor: 500_000,
      expectedCurrency: 'JPY',
      expectedUpdatedAt: null,
    }).success, false)
    assert.equal(emergencyFundGoalSaveSchema.safeParse({
      accountId: 2,
      targetMinor: 500_000,
    }).success, false)
    assert.equal(emergencyFundGoalDeleteSchema.safeParse({
      expectedUpdatedAt: updatedAt,
      accountId: 2,
    }).success, false)
  })
})

const valid = {
  id: '019f5087-229b-7ce3-a76f-95c833dcf251',
  type: 'expense',
  amountMinor: 10_050,
  currency: 'HKD',
  accountId: 1,
  categoryId: 2,
  occurredOn: '2026-07-11',
  cleared: false,
  payee: '百佳超級市場',
  note: '',
}

describe('transaction validation', () => {
  it('accepts a complete HKD transaction', () => {
    assert.equal(transactionInputSchema.safeParse(valid).success, true)
    const { cleared, ...withoutClearingStatus } = valid
    assert.equal(cleared, false)
    assert.equal(transactionInputSchema.parse(withoutClearingStatus).cleared, false)
  })

  for (const [label, patch] of [
    ['fractional minor units', { amountMinor: 1.2 }],
    ['unsafe minor units', { amountMinor: Number.MAX_SAFE_INTEGER + 1 }],
    ['non-UUID id', { id: '1' }],
    ['unsupported currency', { currency: 'JPY' }],
    ['date containing a time', { occurredOn: '2026-07-11T10:30:00.000Z' }],
    ['invalid calendar date', { occurredOn: '2026-02-30' }],
    ['oversized payee', { payee: '商'.repeat(81) }],
  ] as const) {
    it(`rejects ${label}`, () => {
      assert.equal(transactionInputSchema.safeParse({ ...valid, ...patch }).success, false)
    })
  }

  it('rejects unknown input fields', () => {
    assert.equal(transactionInputSchema.safeParse({ ...valid, privateMemo: 'nope' }).success, false)
  })

  it('accepts conflict-safe update and delete payloads', () => {
    const { id, ...fields } = valid
    assert.match(id, /-/)
    const updatedAt = '2026-07-11T10:30:00.000Z'
    assert.equal(transactionUpdateSchema.safeParse({ ...fields, updatedAt }).success, true)
    assert.equal(transactionDeleteSchema.safeParse({ updatedAt }).success, true)
  })

  it('accepts only bounded, unique transaction versions for bulk clearing', () => {
    const updatedAt = '2026-07-11T10:30:00.000Z'
    const transactions = [
      { id: valid.id, updatedAt },
      { id: '019f5087-229b-7ce3-a76f-95c833dcf252', updatedAt },
    ]
    assert.deepEqual(transactionClearingBatchSchema.parse({ cleared: true, transactions }), {
      cleared: true,
      transactions,
    })
    assert.equal(transactionClearingBatchSchema.safeParse({ cleared: true, transactions: [] }).success, false)
    assert.equal(transactionClearingBatchSchema.safeParse({
      cleared: false,
      transactions: [transactions[0], transactions[0]],
    }).success, false)
    assert.equal(transactionClearingBatchSchema.safeParse({
      cleared: false,
      transactions: [{ ...transactions[0], updatedAt: 'yesterday' }],
    }).success, false)
    assert.equal(transactionClearingBatchSchema.safeParse({
      cleared: false,
      transactions: [{ ...transactions[0], note: 'not accepted' }],
    }).success, false)
    assert.equal(transactionClearingBatchSchema.safeParse({
      cleared: false,
      transactions: Array.from({ length: 201 }, (_, index) => ({
        id: `30000000-0000-4000-8000-${String(index).padStart(12, '0')}`,
        updatedAt,
      })),
    }).success, false)
  })

  it('accepts only a strict target category and unique transaction versions for bulk recategorization', () => {
    const updatedAt = '2026-07-11T10:30:00.000Z'
    const transactions = [
      { id: valid.id, updatedAt },
      { id: '019f5087-229b-7ce3-a76f-95c833dcf252', updatedAt },
    ]

    assert.deepEqual(transactionCategoryBatchSchema.parse({ categoryId: 4, transactions }), {
      categoryId: 4,
      transactions,
    })
    assert.equal(transactionCategoryBatchSchema.safeParse({ categoryId: 0, transactions }).success, false)
    assert.equal(transactionCategoryBatchSchema.safeParse({
      categoryId: 4,
      transactions: [transactions[0], transactions[0]],
    }).success, false)
    assert.equal(transactionCategoryBatchSchema.safeParse({
      categoryId: 4,
      transactions,
      applyToFuture: true,
    }).success, false)
  })

  it('accepts only the three import review states and bounded unique imported transaction versions', () => {
    const updatedAt = '2026-07-11T10:30:00.000Z'
    const transactions = [
      { id: valid.id, updatedAt },
      { id: '019f5087-229b-7ce3-a76f-95c833dcf252', updatedAt },
    ]

    for (const status of ['unreviewed', 'reviewed', 'needs_follow_up'] as const) {
      assert.equal(importReviewStatusSchema.safeParse(status).success, true)
      assert.deepEqual(transactionImportReviewBatchSchema.parse({ status, transactions }), {
        status,
        transactions,
      })
    }
    assert.equal(importReviewStatusSchema.safeParse('ignored').success, false)
    assert.equal(transactionImportReviewBatchSchema.safeParse({
      status: 'reviewed',
      transactions: [transactions[0], transactions[0]],
    }).success, false)
    assert.equal(transactionImportReviewBatchSchema.safeParse({
      status: 'reviewed',
      transactions,
      cleared: true,
    }).success, false)
  })

  it('rejects an update that tries to replace its immutable ID', () => {
    const { id, ...fields } = valid
    assert.equal(
      transactionUpdateSchema.safeParse({ ...fields, id, updatedAt: '2026-07-11T10:30:00.000Z' }).success,
      false,
    )
  })

  it('accepts only exact duplicate-check fields and an optional excluded transaction', () => {
    const { id, cleared, ...candidate } = valid
    assert.equal(cleared, false)
    assert.deepEqual(transactionDuplicateCheckSchema.parse(candidate), candidate)
    assert.deepEqual(transactionDuplicateCheckSchema.parse({ ...candidate, excludeId: id }), {
      ...candidate,
      excludeId: id,
    })
    assert.equal(transactionDuplicateCheckSchema.safeParse({ ...candidate, id }).success, false)
    assert.equal(transactionDuplicateCheckSchema.safeParse({ ...candidate, cleared }).success, false)
    assert.equal(transactionDuplicateCheckSchema.safeParse({ ...candidate, privateMemo: 'nope' }).success, false)
    assert.equal(transactionDuplicateCheckSchema.safeParse({ ...candidate, excludeId: '1' }).success, false)
  })
})

describe('transaction query validation', () => {
  const pageCursor = {
    version: 1,
    revision: 42,
    queryKey: '{"month":"2026-07","scope":"month"}',
    sort: 'date_desc',
    payeeBlank: 0,
    amountMinor: 38_640,
    occurredOn: '2026-07-11',
    payee: 'Supermarket',
    createdAt: '2026-07-11T10:30:00.000Z',
    id: '019f5087-229b-7ce3-a76f-95c833dcf253',
  } as const

  it('accepts filters plus a strict transaction order', () => {
    assert.deepEqual(
      transactionQuerySchema.parse({
        month: '2026-07',
        scope: 'all',
        type: 'expense',
        status: 'uncleared',
        importReviewStatus: 'needs_follow_up',
        accountId: '2',
        categoryId: '3',
        amountMinor: '38640',
        payee: '  Supermarket  ',
        search: '超級市場',
        tag: '旅程',
        duplicates: 'exact',
        sort: 'amount_desc',
      }),
      {
        month: '2026-07',
        scope: 'all',
        type: 'expense',
        status: 'uncleared',
        importReviewStatus: 'needs_follow_up',
        accountId: 2,
        categoryId: 3,
        amountMinor: 38_640,
        payee: 'Supermarket',
        search: '超級市場',
        tag: '旅程',
        duplicates: 'exact',
        sort: 'amount_desc',
      },
    )
    assert.equal(transactionQuerySchema.parse({ month: '2026-07' }).scope, 'month')
  })

  it('accepts only complete, ordered custom date ranges', () => {
    assert.deepEqual(transactionQuerySchema.parse({
      month: '2026-07',
      scope: 'range',
      dateFrom: '2025-04-01',
      dateTo: '2026-03-31',
    }), {
      month: '2026-07',
      scope: 'range',
      dateFrom: '2025-04-01',
      dateTo: '2026-03-31',
    })

    for (const query of [
      { month: '2026-07', scope: 'range', dateFrom: '2026-07-01' },
      { month: '2026-07', scope: 'range', dateTo: '2026-07-31' },
      { month: '2026-07', scope: 'range', dateFrom: '2026-08-01', dateTo: '2026-07-31' },
      { month: '2026-07', scope: 'range', dateFrom: '2026-02-30', dateTo: '2026-03-01' },
      { month: '2026-07', scope: 'month', dateFrom: '2026-07-01', dateTo: '2026-07-31' },
      { month: '2026-07', scope: 'all', dateFrom: '2026-07-01', dateTo: '2026-07-31' },
    ] as const) {
      assert.equal(transactionQuerySchema.safeParse(query).success, false)
    }
  })

  it('accepts only a strict continuation cursor for the selected order', () => {
    assert.deepEqual(transactionPageQuerySchema.parse({
      month: '2026-07',
      cursor: pageCursor,
    }), {
      month: '2026-07',
      scope: 'month',
      cursor: pageCursor,
    })
    for (const sort of [
      'date_desc',
      'date_asc',
      'amount_desc',
      'amount_asc',
      'payee_asc',
      'payee_desc',
    ] as const) {
      assert.equal(transactionPageQuerySchema.safeParse({
        month: '2026-07',
        sort,
        cursor: { ...pageCursor, sort },
      }).success, true)
    }

    for (const cursor of [
      { ...pageCursor, version: 2 },
      { ...pageCursor, revision: 0 },
      { ...pageCursor, revision: Number.MAX_SAFE_INTEGER + 1 },
      { ...pageCursor, queryKey: '' },
      { ...pageCursor, payeeBlank: 2 },
      { ...pageCursor, amountMinor: 0 },
      { ...pageCursor, occurredOn: '2026-02-29' },
      { ...pageCursor, payee: 'x'.repeat(81) },
      { ...pageCursor, createdAt: '2026-07-11' },
      { ...pageCursor, id: 'not-a-uuid' },
      { ...pageCursor, privateMemo: 'never accept' },
    ]) {
      assert.equal(transactionPageQuerySchema.safeParse({
        month: '2026-07',
        cursor,
      }).success, false)
    }
  })

  it('rejects cursor reuse under another order and keeps export filters cursor-free', () => {
    assert.equal(transactionPageQuerySchema.safeParse({
      month: '2026-07',
      sort: 'amount_desc',
      cursor: pageCursor,
    }).success, false)
    assert.equal(transactionQuerySchema.safeParse({
      month: '2026-07',
      cursor: pageCursor,
    }).success, false)
  })

  for (const [index, query] of [
    { month: '2026-13' },
    { type: 'transfer' },
    { month: '2026-07', status: 'pending' },
    { month: '2026-07', importReviewStatus: 'ignored' },
    { accountId: '0' },
    { categoryId: '1.5' },
    { month: '2026-07', amountMinor: '0' },
    { month: '2026-07', amountMinor: '1.5' },
    { month: '2026-07', amountMinor: String(Number.MAX_SAFE_INTEGER + 1) },
    { payee: '   ' },
    { payee: 'x'.repeat(81) },
    { search: 'x'.repeat(81) },
    { tag: 'trip,' },
    { tag: '#trip' },
    { month: '2026-07', duplicates: 'fuzzy' },
    { month: '2026-07', sort: 'amount; DROP TABLE transactions' },
    { month: '2026-07', scope: 'year' },
  ].entries()) {
    it(`rejects invalid query ${index}`, () => {
      assert.equal(transactionQuerySchema.safeParse(query).success, false)
    })
  }
})

describe('account transfer validation', () => {
  const transfer = {
    id: '019f5087-229b-7ce3-a76f-95c833dcf253',
    amountMinor: 50_000,
    currency: 'HKD',
    fromAccountId: 1,
    toAccountId: 2,
    occurredOn: '2026-07-11',
    fromCleared: true,
    toCleared: false,
    note: 'Cash withdrawal',
  } as const

  it('accepts an exact two-sided HKD transfer', () => {
    assert.deepEqual(accountTransferInputSchema.parse(transfer), transfer)
  })

  it('rejects self-transfers, unsafe amounts, dates with times, and extra fields', () => {
    assert.equal(accountTransferInputSchema.safeParse({ ...transfer, toAccountId: 1 }).success, false)
    assert.equal(accountTransferInputSchema.safeParse({
      ...transfer,
      amountMinor: Number.MAX_SAFE_INTEGER + 1,
    }).success, false)
    assert.equal(accountTransferInputSchema.safeParse({
      ...transfer,
      occurredOn: '2026-07-11T10:30:00.000Z',
    }).success, false)
    assert.equal(accountTransferInputSchema.safeParse({ ...transfer, categoryId: 3 }).success, false)
    assert.equal(accountTransferInputSchema.safeParse({
      ...transfer,
      recurringTransferRuleId: '019f5087-229b-7ce3-a76f-95c833dcf254',
      recurringTransferRuleName: 'Savings',
      recurrenceDueOn: '2026-07-11',
      recurringOccurrenceKey: '019f5087-229b-7ce3-a76f-95c833dcf254:2026-07-11',
    }).success, false)
  })

  it('uses a conflict token without allowing an ID replacement', () => {
    const { id, ...fields } = transfer
    const updatedAt = '2026-07-11T10:30:00.000Z'
    assert.equal(accountTransferUpdateSchema.safeParse({ ...fields, updatedAt }).success, true)
    assert.equal(accountTransferUpdateSchema.safeParse({ ...fields, id, updatedAt }).success, false)
    assert.equal(accountTransferUpdateSchema.safeParse({
      ...fields,
      recurringTransferRuleId: '019f5087-229b-7ce3-a76f-95c833dcf254',
      updatedAt,
    }).success, false)
    const { toCleared: _toCleared, ...missingPostingState } = fields
    assert.equal(_toCleared, false)
    assert.equal(accountTransferUpdateSchema.safeParse({ ...missingPostingState, updatedAt }).success, false)
  })

  it('accepts either a strict calendar month or an inclusive statement range', () => {
    assert.deepEqual(accountTransferQuerySchema.parse({ month: '2026-07' }), { month: '2026-07' })
    assert.deepEqual(accountTransferQuerySchema.parse({ month: '2026-07', accountId: '2' }), {
      month: '2026-07',
      accountId: 2,
    })
    assert.deepEqual(accountTransferQuerySchema.parse({
      dateFrom: '2026-06-13',
      dateTo: '2026-07-12',
      accountId: '2',
    }), {
      dateFrom: '2026-06-13',
      dateTo: '2026-07-12',
      accountId: 2,
    })

    for (const query of [
      { month: '2026-13' },
      { month: '2026-07', accountId: '0' },
      { dateFrom: '2026-06-13' },
      { dateTo: '2026-07-12' },
      { dateFrom: '2026-07-13', dateTo: '2026-07-12' },
      { dateFrom: '2026-02-29', dateTo: '2026-03-01' },
      { month: '2026-07', dateFrom: '2026-06-13', dateTo: '2026-07-12' },
      { month: '2026-07', other: '1' },
    ] as const) {
      assert.equal(accountTransferQuerySchema.safeParse(query).success, false)
    }
  })
})

const validRecurringTransferRule = {
  id: '019f5087-229b-7ce3-a76f-95c833dcf254',
  name: 'Emergency savings',
  amountMinor: 50_000,
  currency: 'HKD',
  fromAccountId: 1,
  toAccountId: 2,
  frequency: 'monthly',
  scheduleStartsOn: '2026-08-01',
  isActive: true,
  note: '',
} as const

describe('recurring transfer rule validation', () => {
  it('accepts strict create, update, status, skip, and delete payloads', () => {
    for (const frequency of ['daily', 'weekly', 'monthly', 'yearly'] as const) {
      assert.equal(recurringTransferRuleCreateSchema.safeParse({
        ...validRecurringTransferRule,
        frequency,
      }).success, true)
    }
    assert.equal(recurringTransferRuleCreateSchema.safeParse({
      ...validRecurringTransferRule,
      scheduleEndsOn: null,
    }).success, true)

    const { id, ...update } = validRecurringTransferRule
    assert.match(id, /-/)
    assert.equal(recurringTransferRuleUpdateSchema.safeParse({
      ...update,
      revision: 1,
    }).success, true)
    assert.equal(recurringTransferRuleStatusSchema.safeParse({
      isActive: false,
      revision: 1,
    }).success, true)
    assert.equal(recurringTransferRuleSkipSchema.safeParse({
      revision: 1,
      nextOccurrenceOn: '2026-08-01',
    }).success, true)
    assert.equal(recurringTransferRuleDeleteSchema.safeParse({ revision: 1 }).success, true)
  })

  for (const [label, patch] of [
    ['same account', { toAccountId: 1 }],
    ['zero amount', { amountMinor: 0 }],
    ['unsafe amount', { amountMinor: Number.MAX_SAFE_INTEGER + 1 }],
    ['unsupported currency', { currency: 'JPY' }],
    ['unsupported frequency', { frequency: 'quarterly' }],
    ['invalid start date', { scheduleStartsOn: '2026-02-30' }],
    ['end before start', { scheduleEndsOn: '2026-07-31' }],
    ['caller-supplied provenance', {
      recurringTransferRuleId: '019f5087-229b-7ce3-a76f-95c833dcf254',
      recurrenceDueOn: '2026-08-01',
    }],
  ] as const) {
    it(`rejects ${label}`, () => {
      assert.equal(recurringTransferRuleCreateSchema.safeParse({
        ...validRecurringTransferRule,
        ...patch,
      }).success, false)
    })
  }

  it('accepts an omitted end on update but rejects a supplied end before start', () => {
    const { id, ...update } = validRecurringTransferRule
    assert.match(id, /-/)
    assert.equal(recurringTransferRuleUpdateSchema.safeParse({
      ...update,
      revision: 1,
    }).success, true)
    assert.equal(recurringTransferRuleUpdateSchema.safeParse({
      ...update,
      scheduleEndsOn: '2026-07-31',
      revision: 1,
    }).success, false)
    assert.equal(recurringTransferRuleUpdateSchema.safeParse({
      ...update,
      recurringOccurrenceKey: 'caller-value',
      revision: 1,
    }).success, false)
  })

  it('rejects a same-ID replay that tries to vary the first date outside the canonical schedule', () => {
    assert.equal(recurringTransferRuleCreateSchema.safeParse({
      ...validRecurringTransferRule,
      firstOccurrenceOn: '2026-09-01',
    }).success, false)
  })
})

const validRecurringRule = {
  id: '019f5087-229b-7ce3-a76f-95c833dcf252',
  name: '家居租金',
  type: 'expense',
  amountMinor: 1_200_000,
  currency: 'HKD',
  accountId: 2,
  categoryId: 6,
  frequency: 'monthly',
  scheduleStartsOn: '2026-08-01',
  isActive: true,
  payee: '業主',
  note: '',
}

describe('recurring rule validation', () => {
  it('accepts create, update, status, skip, and delete payloads', () => {
    assert.equal(recurringRuleCreateSchema.safeParse(validRecurringRule).success, true)
    assert.equal(recurringRuleCreateSchema.safeParse({
      ...validRecurringRule,
      scheduleEndsOn: null,
    }).success, true)
    assert.equal(recurringRuleCreateSchema.safeParse({
      ...validRecurringRule,
      scheduleEndsOn: '2026-08-01',
    }).success, true)
    assert.equal(recurringRuleCreateSchema.safeParse({
      ...validRecurringRule,
      firstOccurrenceOn: '2026-09-01',
      scheduleEndsOn: '2026-09-01',
    }).success, true)
    const { id, ...update } = validRecurringRule
    assert.match(id, /-/)
    assert.equal(recurringRuleUpdateSchema.safeParse({ ...update, revision: 1 }).success, true)
    assert.equal(recurringRuleUpdateSchema.safeParse({
      ...update,
      scheduleEndsOn: null,
      revision: 1,
    }).success, true)
    assert.equal(recurringRuleUpdateSchema.safeParse({
      ...update,
      frequency: 'yearly',
      revision: 1,
    }).success, true)
    assert.equal(recurringRuleStatusSchema.safeParse({ isActive: false, revision: 1 }).success, true)
    assert.equal(recurringRuleSkipSchema.safeParse({
      revision: 1,
      nextOccurrenceOn: '2026-08-01',
    }).success, true)
    assert.equal(recurringRuleDeleteSchema.safeParse({ revision: 1 }).success, true)
    assert.equal(recurringRuleCreateSchema.safeParse({
      ...validRecurringRule,
      frequency: 'yearly',
    }).success, true)
    assert.equal(recurringRuleSkipSchema.safeParse({
      revision: 1,
      nextOccurrenceOn: '2026-02-30',
    }).success, false)
    assert.equal(recurringRuleSkipSchema.safeParse({
      revision: 1,
      nextOccurrenceOn: '2026-08-01',
      extra: true,
    }).success, false)
  })

  for (const [label, patch] of [
    ['unsupported frequency', { frequency: 'quarterly' }],
    ['invalid start date', { scheduleStartsOn: '2026-02-30' }],
    ['invalid end date', { scheduleEndsOn: '2026-02-30' }],
    ['end date before the anchor date', { scheduleEndsOn: '2026-07-31' }],
    ['first occurrence before the anchor date', { firstOccurrenceOn: '2026-07-31' }],
    ['end date before the first occurrence', {
      firstOccurrenceOn: '2026-09-01',
      scheduleEndsOn: '2026-08-31',
    }],
    ['empty rule name', { name: '   ' }],
    ['fractional amount', { amountMinor: 1.5 }],
    ['unknown field', { privateInstruction: 'nope' }],
  ] as const) {
    it(`rejects ${label}`, () => {
      assert.equal(recurringRuleCreateSchema.safeParse({ ...validRecurringRule, ...patch }).success, false)
    })
  }

  it('rejects an update end date before its schedule start', () => {
    const { id, ...update } = validRecurringRule
    assert.match(id, /-/)
    assert.equal(recurringRuleUpdateSchema.safeParse({
      ...update,
      scheduleEndsOn: '2026-07-31',
      revision: 1,
    }).success, false)
  })
})
