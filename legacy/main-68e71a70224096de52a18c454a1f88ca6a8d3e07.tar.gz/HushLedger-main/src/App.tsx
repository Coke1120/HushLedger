'use client'

import { ChevronRight } from 'lucide-react'
import { useCallback, useDeferredValue, useEffect, useRef, useState } from 'react'
import { AppHeader } from './components/AppHeader'
import { AiCopilotPanel } from './components/AiCopilotPanel'
import { aiCopilotActionIsCurrent } from './components/aiCopilotActionSafety'
import { BankImportPanel } from './components/BankImportPanel'
import { AccountTransferDialog } from './components/AccountTransferDialog'
import { AccountTransferList } from './components/AccountTransferList'
import { AccountBalances } from './components/AccountBalances'
import { AccountRegister } from './components/AccountRegister'
import { CategorySpending } from './components/CategorySpending'
import { ConnectionBanner } from './components/ConnectionBanner'
import { CsvImportPanel } from './components/CsvImportPanel'
import { EmergencyFundProgress } from './components/EmergencyFundProgress'
import { IncomeSources } from './components/IncomeSources'
import { LedgerBackupReminder } from './components/LedgerBackupReminder'
import { MobileNavigation, type AppView } from './components/MobileNavigation'
import { MonthNavigator } from './components/MonthNavigator'
import { MonthlySpendingPlans } from './components/MonthlySpendingPlans'
import { NetWorthTrend } from './components/NetWorthTrend'
import {
  OverviewMonthlyReview,
  type OverviewReview,
} from './components/OverviewMonthlyReview'
import { RecurringRulesPage } from './components/RecurringRulesPage'
import { RecurringForecast } from './components/RecurringForecast'
import { SavedTransactionViews } from './components/SavedTransactionViews'
import { SettingsPage, type SettingsCategory } from './components/SettingsPage'
import { SummaryCards } from './components/SummaryCards'
import { CashFlowTrend } from './components/CashFlowTrend'
import { useAppUpdate } from './components/appUpdateContext'
import { TransactionDialog } from './components/TransactionDialog'
import { TransactionFilterSummary } from './components/TransactionFilterSummary'
import { TransactionList } from './components/TransactionList'
import {
  TransactionToolbar,
  type TransactionClearingFilter,
  type TransactionFilter,
  type TransactionImportReviewFilter,
} from './components/TransactionToolbar'
import { useHongKongToday } from './hooks/useHongKongToday'
import { useMoneyData } from './hooks/useMoneyData'
import { startScheduledOutlookRefreshRetries } from './hooks/scheduledOutlookRefresh'
import { useI18n } from './i18n'
import { inclusiveMonthRangeDates, shiftMonth } from './lib/date'
import {
  aiProviderSettingsSchema,
  canUseStoredAiProvider,
  type AiProviderSettings,
  type AiProviderSettingsRow,
} from './lib/ai'
import type { AiCopilotAction } from './lib/aiCopilot'
import {
  aiSettingsDraftHasConflict,
  aiSettingsRowOverrideIsSuperseded,
  updateAiSettingsDraft,
  type AiSettingsDraft,
  type AiSettingsRowOverride,
} from './lib/aiSettingsDraft'
import { recurringRuleDraftFromTransaction } from './lib/recurringDraft'
import { api } from './lib/api'
import { TRANSACTION_PAGE_SIZE } from './lib/schema'
import {
  addSavedTransactionView,
  applySavedTransactionViewsStorageChange,
  forgetSavedTransactionViews,
  parseSavedTransactionViews,
  SAVED_TRANSACTION_VIEWS_STORAGE_KEY,
  serializeSavedTransactionViews,
  type SavedTransactionView,
} from './lib/savedTransactionViews'
import type {
  RecurringRuleCreateInput,
  AccountTransfer,
  AccountTransferInput,
  Transaction,
  TransactionDateScope,
  TransactionInput,
  TransactionSort,
} from './lib/schema'
import { duplicateTransactionDraft } from './lib/transactionDraft'

const initialAiSettings: AiProviderSettings = {
  baseUrl: 'https://api.openai.com/v1',
  apiKey: '',
  model: '',
}

function App({
  initialDate,
  initialMonth,
  publicDemo,
}: {
  initialDate: string
  initialMonth: string
  publicDemo: boolean
}) {
  const { localizeEntityName, t } = useI18n()
  const scheduledOutlookToday = useHongKongToday()
  const { status: appUpdateStatus, setRestartBlocked } = useAppUpdate()
  const [month, setMonth] = useState(initialMonth)
  const [filter, setFilter] = useState<TransactionFilter>('all')
  const [clearingFilter, setClearingFilter] = useState<TransactionClearingFilter>('all')
  const [importReviewFilter, setImportReviewFilter] = useState<TransactionImportReviewFilter>('all')
  const [accountFilterId, setAccountFilterId] = useState<number | null>(null)
  const [registerAccountId, setRegisterAccountId] = useState<number | null>(null)
  const [registerMode, setRegisterMode] = useState<'review' | 'reconcile'>('review')
  const [registerDateRange, setRegisterDateRange] = useState<{
    month: string
    from: string
    to: string
  } | null>(null)
  const [registerStatementBalance, setRegisterStatementBalance] = useState<{
    month: string
    minor: number
  } | null>(null)
  const [categoryFilterId, setCategoryFilterId] = useState<number | null>(null)
  const [payeeFilter, setPayeeFilter] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [amountFilterMinor, setAmountFilterMinor] = useState<number | null>(null)
  const [tagFilter, setTagFilter] = useState<string | null>(null)
  const [transactionSort, setTransactionSort] = useState<TransactionSort>('date_desc')
  const [transactionDateScope, setTransactionDateScope] = useState<TransactionDateScope>('month')
  const [customTransactionDateRange, setCustomTransactionDateRange] = useState<{
    from: string
    to: string
  } | null>(null)
  const [duplicatesOnly, setDuplicatesOnly] = useState(false)
  const [view, setView] = useState<AppView>('overview')
  const [overviewReview, setOverviewReview] = useState<OverviewReview>('spending')
  const [settingsCategory, setSettingsCategory] = useState<SettingsCategory>('ledger')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [transferDialogOpen, setTransferDialogOpen] = useState(false)
  const [editingTransfer, setEditingTransfer] = useState<AccountTransfer | null>(null)
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null)
  const [transactionDraft, setTransactionDraft] = useState<TransactionInput | null>(null)
  const [transactionDraftKind, setTransactionDraftKind] = useState<'duplicate' | 'ai' | null>(null)
  const [recurringDraft, setRecurringDraft] = useState<RecurringRuleCreateInput | null>(null)
  const [recurringDraftKind, setRecurringDraftKind] = useState<'manual' | 'ai' | null>(null)
  const [recurringRuleFocusId, setRecurringRuleFocusId] = useState<string | null>(null)
  const [recurringTransferRuleFocusId, setRecurringTransferRuleFocusId] = useState<string | null>(null)
  const [importMode, setImportMode] = useState<'csv' | 'copilot' | 'statement' | null>(null)
  const [aiCopilotActionStale, setAiCopilotActionStale] = useState(false)
  const [aiSettingsDraft, setAiSettingsDraft] = useState<AiSettingsDraft | null>(null)
  const [aiSettingsRowOverride, setAiSettingsRowOverride] = useState<
    AiSettingsRowOverride | null
  >(null)

  const [savedTransactionViews, setSavedTransactionViews] = useState<SavedTransactionView[]>([])
  const [ledgerGeneration, setLedgerGeneration] = useState(0)
  const [ledgerRestoreInProgress, setLedgerRestoreInProgress] = useState(false)
  const [importMutationInProgress, setImportMutationInProgress] = useState(false)
  const [recurringMutationInProgress, setRecurringMutationInProgress] = useState(false)
  const [settingsMutationInProgress, setSettingsMutationInProgress] = useState(false)
  const [ledgerBackupDue, setLedgerBackupDue] = useState<boolean | null>(null)
  const mainRef = useRef<HTMLElement>(null)
  const transactionsPanelRef = useRef<HTMLElement>(null)
  const csvImportButtonRef = useRef<HTMLButtonElement>(null)
  const aiStatementImportButtonRef = useRef<HTMLButtonElement>(null)
  const aiCopilotButtonRef = useRef<HTMLButtonElement>(null)
  const importPanelRef = useRef<HTMLElement>(null)
  const importReturnFocusRef = useRef<HTMLButtonElement | null>(null)
  const transactionLoadStatusRef = useRef<HTMLParagraphElement>(null)
  const initialViewRef = useRef(true)
  const deferredSearch = useDeferredValue(search)
  const selectedMonthDateRange = inclusiveMonthRangeDates(month)
  const transactionDateRange = customTransactionDateRange ?? {
    from: selectedMonthDateRange.start,
    to: selectedMonthDateRange.end,
  }
  const effectiveRegisterDateRange = registerDateRange?.month === month
    ? registerDateRange
    : { month, from: selectedMonthDateRange.start, to: selectedMonthDateRange.end }
  const effectiveTransactionDateScope = registerAccountId !== null
    ? 'range'
    : view === 'transactions' ? transactionDateScope : 'month'
  const effectiveTransactionDateRange = registerAccountId === null
    ? transactionDateRange
    : effectiveRegisterDateRange
  const data = useMoneyData(
    month,
    filter,
    deferredSearch,
    accountFilterId,
    categoryFilterId,
    payeeFilter,
    tagFilter,
    clearingFilter,
    importReviewFilter,
    view === 'transactions' ? transactionSort : 'date_desc',
    duplicatesOnly,
    effectiveTransactionDateScope,
    effectiveTransactionDateRange.from,
    effectiveTransactionDateRange.to,
    registerAccountId,
    registerAccountId === null ? amountFilterMinor : null,
    publicDemo,
  )
  const {
    clearActionMessage,
    refresh: refreshMoneyData,
    removeTransaction,
    removeAccountTransfer,
    setAccountRegisterEntryClearing,
    setSelectedTransactionsCategory,
    setSelectedTransactionsClearing,
    setSelectedTransactionsImportReviewStatus,
    saveAccountTransfer,
    saveTransaction: saveMoneyTransaction,
  } = data
  const otherLedgerMutationInProgress = data.saving
    || importMutationInProgress
    || recurringMutationInProgress
  const ledgerMutationInProgress = otherLedgerMutationInProgress || settingsMutationInProgress
  const ledgerInteractionLocked = ledgerRestoreInProgress || ledgerMutationInProgress
  const transactionEntryDisabled = ledgerInteractionLocked
    || data.source !== 'live'
    || !data.online
  const currentAiSettingsRowOverride = aiSettingsRowOverride
    && !aiSettingsRowOverrideIsSuperseded(
      aiSettingsRowOverride,
      data.aiProviderSettings?.updatedAt ?? null,
    )
    ? aiSettingsRowOverride
    : null
  const aiSettingsRow = currentAiSettingsRowOverride
    ? currentAiSettingsRowOverride.settings
    : (data.aiProviderSettings ?? null)
  const aiSettings: AiProviderSettings = aiSettingsDraft?.settings ?? (aiSettingsRow
    ? { baseUrl: aiSettingsRow.baseUrl, apiKey: '', model: aiSettingsRow.model }
    : initialAiSettings)
  const aiSettingsConflict = aiSettingsDraftHasConflict(
    aiSettingsDraft,
    aiSettingsRow?.updatedAt ?? null,
  )
  const aiStatementImportConfigured = aiProviderSettingsSchema.safeParse(aiSettings).success
    || canUseStoredAiProvider(
      aiSettings,
      aiSettingsRow,
      data.aiProviderSettingsStatus === 'ready',
      aiSettingsConflict,
    )

  const changeAiSettings = useCallback((settings: AiProviderSettings) => {
    setAiSettingsDraft((current) => updateAiSettingsDraft(
      current,
      settings,
      aiSettingsRow?.updatedAt ?? null,
    ))
  }, [aiSettingsRow?.updatedAt])

  const saveAiSettings = useCallback(async (settings: AiProviderSettings) => {
    if (data.aiProviderSettingsStatus !== 'ready') {
      throw new Error('AI settings metadata is unavailable')
    }
    const expectedUpdatedAt = aiSettingsDraft?.baseUpdatedAt ?? aiSettingsRow?.updatedAt ?? null
    const saved = await api<AiProviderSettingsRow>('/api/ai-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        settings: {
          baseUrl: settings.baseUrl,
          model: settings.model,
          ...(settings.apiKey.trim() ? { apiKey: settings.apiKey } : {}),
        },
        expectedUpdatedAt,
      }),
    })
    setAiSettingsRowOverride({ settings: saved, replacedUpdatedAt: expectedUpdatedAt })
    setAiSettingsDraft(null)
    await data.refresh('preserve')
  }, [aiSettingsDraft?.baseUpdatedAt, aiSettingsRow?.updatedAt, data])

  const deleteAiSettings = useCallback(async () => {
    if (data.aiProviderSettingsStatus !== 'ready') {
      throw new Error('AI settings metadata is unavailable')
    }
    if (!aiSettingsRow) return
    const expectedUpdatedAt = aiSettingsDraft?.baseUpdatedAt ?? aiSettingsRow.updatedAt
    await api<{ deleted: true }>('/api/ai-settings', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ expectedUpdatedAt }),
    })
    setAiSettingsRowOverride({ settings: null, replacedUpdatedAt: expectedUpdatedAt })
    setAiSettingsDraft(null)
    await data.refresh('preserve')
  }, [aiSettingsDraft?.baseUpdatedAt, aiSettingsRow, data])
  const scheduledOutlookStartOn = data.summary.scheduledOutlook?.startOn

  useEffect(() => {
    if (
      data.source !== 'live'
      || scheduledOutlookStartOn === undefined
      || scheduledOutlookStartOn === scheduledOutlookToday
      || ledgerInteractionLocked
    ) return

    return startScheduledOutlookRefreshRetries(
      () => refreshMoneyData('preserve'),
    )
  }, [
    data.source,
    ledgerInteractionLocked,
    refreshMoneyData,
    scheduledOutlookStartOn,
    scheduledOutlookToday,
  ])

  const changeLedgerRestoreState = useCallback((restoring: boolean) => {
    if (restoring && (ledgerMutationInProgress || appUpdateStatus === 'installing')) return false
    if (restoring) setRestartBlocked(true)
    setLedgerRestoreInProgress(restoring)
    return true
  }, [appUpdateStatus, ledgerMutationInProgress, setRestartBlocked])

  const openDialog = useCallback(() => {
    if (transactionEntryDisabled) return
    clearActionMessage()
    setEditingTransaction(null)
    setTransactionDraft(null)
    setTransactionDraftKind(null)
    setDialogOpen(true)
  }, [clearActionMessage, transactionEntryDisabled])

  const openTransaction = useCallback((transaction: Transaction) => {
    if (ledgerInteractionLocked) return
    clearActionMessage()
    setEditingTransaction(transaction)
    setTransactionDraft(null)
    setTransactionDraftKind(null)
    setDialogOpen(true)
  }, [clearActionMessage, ledgerInteractionLocked])

  const duplicateTransaction = useCallback((transaction: Transaction) => {
    clearActionMessage()
    setEditingTransaction(null)
    setTransactionDraft(duplicateTransactionDraft(transaction))
    setTransactionDraftKind('duplicate')
    setDialogOpen(true)
  }, [clearActionMessage])

  const closeDialog = useCallback(() => {
    setDialogOpen(false)
    setEditingTransaction(null)
    setTransactionDraft(null)
    setTransactionDraftKind(null)
  }, [])
  const openTransferDialog = useCallback((transfer: AccountTransfer | null = null) => {
    if (ledgerInteractionLocked) return
    clearActionMessage()
    setEditingTransfer(transfer)
    setTransferDialogOpen(true)
  }, [clearActionMessage, ledgerInteractionLocked])
  const closeTransferDialog = useCallback(() => {
    setTransferDialogOpen(false)
    setEditingTransfer(null)
  }, [])
  const closeRecurringDraft = useCallback(() => {
    setRecurringDraft(null)
    setRecurringDraftKind(null)
  }, [])
  const clearRecurringRuleFocus = useCallback(() => setRecurringRuleFocusId(null), [])
  const clearRecurringTransferRuleFocus = useCallback(
    () => setRecurringTransferRuleFocusId(null),
    [],
  )

  const saveTransaction = useCallback(
    async (input: TransactionInput) => saveMoneyTransaction(input, editingTransaction ?? undefined),
    [editingTransaction, saveMoneyTransaction],
  )
  const saveTransfer = useCallback(
    async (input: AccountTransferInput) => saveAccountTransfer(input, editingTransfer ?? undefined),
    [editingTransfer, saveAccountTransfer],
  )
  const changeView = useCallback((nextView: AppView) => {
    if (ledgerInteractionLocked) return
    if (nextView !== 'transactions') {
      setRegisterAccountId(null)
      setImportMode(null)
      importReturnFocusRef.current = null
    }
    if (nextView !== 'recurring') {
      setRecurringRuleFocusId(null)
      setRecurringTransferRuleFocusId(null)
    }
    setView(nextView)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [ledgerInteractionLocked])

  const openSettings = useCallback((category: SettingsCategory) => {
    if (ledgerInteractionLocked) return
    setSettingsCategory(category)
    changeView('settings')
  }, [changeView, ledgerInteractionLocked])

  useEffect(() => {
    if (!ledgerRestoreInProgress) {
      setRestartBlocked(false)
      return
    }
    const warnBeforeLeaving = (event: BeforeUnloadEvent) => {
      event.preventDefault()
      event.returnValue = ''
    }
    window.addEventListener('beforeunload', warnBeforeLeaving)
    return () => window.removeEventListener('beforeunload', warnBeforeLeaving)
  }, [ledgerRestoreInProgress, setRestartBlocked])

  const makeTransactionRecurring = useCallback((transaction: Transaction) => {
    const draftName = transaction.payee.trim() || localizeEntityName(
      transaction.categoryName,
      transaction.categoryLocalizationKey,
    )
    clearActionMessage()
    closeDialog()
    setImportMode(null)
    setRecurringDraft(recurringRuleDraftFromTransaction(transaction, draftName))
    setRecurringDraftKind('manual')
    changeView('recurring')
  }, [changeView, clearActionMessage, closeDialog, localizeEntityName])

  const openImport = useCallback((
    mode: 'csv' | 'copilot' | 'statement',
    trigger?: HTMLButtonElement,
  ) => {
    if (ledgerInteractionLocked) return
    const fallbackButton = mode === 'csv'
      ? csvImportButtonRef.current
      : mode === 'statement'
        ? aiStatementImportButtonRef.current
        : aiCopilotButtonRef.current
    importReturnFocusRef.current = trigger
      ?? fallbackButton
      ?? (document.activeElement instanceof HTMLButtonElement ? document.activeElement : null)
    setAiCopilotActionStale(false)
    setRegisterAccountId(null)
    setView('transactions')
    setImportMode(mode)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [ledgerInteractionLocked])

  const closeImport = useCallback(() => {
    const fallbackButton = importMode === 'csv'
      ? csvImportButtonRef.current
      : importMode === 'statement'
        ? aiStatementImportButtonRef.current
        : aiCopilotButtonRef.current
    const returnButton = importReturnFocusRef.current
    const focusTarget = returnButton?.isConnected && !returnButton.disabled
      ? returnButton
      : fallbackButton?.isConnected && !fallbackButton.disabled
        ? fallbackButton
        : transactionsPanelRef.current ?? mainRef.current
    importReturnFocusRef.current = null
    setImportMode(null)
    requestAnimationFrame(() => focusTarget?.focus())
  }, [importMode])

  const changeTransactionFilter = useCallback((nextFilter: TransactionFilter) => {
    setFilter(nextFilter)
    if (nextFilter === 'all') return
    setCategoryFilterId((currentCategoryId) => {
      const category = data.categories.find((item) => item.id === currentCategoryId)
      return category && category.type !== nextFilter ? null : currentCategoryId
    })
  }, [data.categories])

  const clearReferenceFilters = useCallback(() => {
    setAccountFilterId(null)
    setCategoryFilterId(null)
  }, [])

  const changeTransactionDateFrom = useCallback((from: string) => {
    const fallback = inclusiveMonthRangeDates(month)
    setCustomTransactionDateRange((current) => {
      const to = current?.to ?? fallback.end
      return { from, to: from > to ? from : to }
    })
  }, [month])

  const changeTransactionDateTo = useCallback((to: string) => {
    const fallback = inclusiveMonthRangeDates(month)
    setCustomTransactionDateRange((current) => {
      const from = current?.from ?? fallback.start
      return { from: to < from ? to : from, to }
    })
  }, [month])

  const openCategoryTransactions = useCallback((categoryId: number) => {
    const category = data.categories.find((item) => item.id === categoryId)
    if (!category) return
    setSearch('')
    setAmountFilterMinor(null)
    setTransactionDateScope('month')
    setTagFilter(null)
    setDuplicatesOnly(false)
    setFilter(category.type)
    setClearingFilter('all')
    setImportReviewFilter('all')
    setAccountFilterId(null)
    setRegisterAccountId(null)
    setCategoryFilterId(category.id)
    setPayeeFilter(null)
    setImportMode(null)
    changeView('transactions')
  }, [changeView, data.categories])

  const openPayeeTransactions = useCallback((payee: string) => {
    setSearch('')
    setAmountFilterMinor(null)
    setTransactionDateScope('month')
    setTagFilter(null)
    setDuplicatesOnly(false)
    setFilter('expense')
    setClearingFilter('all')
    setImportReviewFilter('all')
    setAccountFilterId(null)
    setRegisterAccountId(null)
    setCategoryFilterId(null)
    setPayeeFilter(payee)
    setImportMode(null)
    changeView('transactions')
  }, [changeView])

  const openAccountRegister = useCallback((
    accountId: number,
    mode: 'review' | 'reconcile',
    statement?: {
      dateFrom: string
      dateTo: string
      closingBalanceMinor: number
    },
  ) => {
    if (!data.accounts.some((account) => account.id === accountId)) return
    setSearch('')
    setAmountFilterMinor(null)
    setTransactionDateScope('month')
    setTagFilter(null)
    setFilter('all')
    setClearingFilter('all')
    setImportReviewFilter('all')
    setDuplicatesOnly(false)
    setPayeeFilter(null)
    setRegisterDateRange(statement
      ? { month, from: statement.dateFrom, to: statement.dateTo }
      : null)
    setRegisterStatementBalance(statement
      ? { month, minor: statement.closingBalanceMinor }
      : null)
    if (data.source === 'live' && data.online) {
      setAccountFilterId(null)
      setRegisterAccountId(accountId)
      setRegisterMode(mode)
    } else {
      setAccountFilterId(accountId)
      setRegisterAccountId(null)
    }
    setCategoryFilterId(null)
    setTransactionSort('date_desc')
    setImportMode(null)
    changeView('transactions')
  }, [changeView, data.accounts, data.online, data.source, month])

  const openAccountTransactions = useCallback((accountId: number) => {
    openAccountRegister(accountId, 'review')
  }, [openAccountRegister])

  const openAccountReconciliation = useCallback((accountId: number) => {
    openAccountRegister(accountId, 'reconcile')
  }, [openAccountRegister])

  const openImportedStatementReconciliation = useCallback((statement: {
    accountId: number
    dateFrom: string
    dateTo: string
    closingBalanceMinor: number
  }) => {
    openAccountRegister(statement.accountId, 'reconcile', statement)
  }, [openAccountRegister])

  const closeAccountRegister = useCallback(() => {
    if (ledgerInteractionLocked) return
    setAccountFilterId(registerAccountId)
    setRegisterAccountId(null)
    setRegisterMode('review')
    setRegisterDateRange(null)
    setRegisterStatementBalance(null)
  }, [ledgerInteractionLocked, registerAccountId])

  const changeRegisterDateRange = useCallback((from: string, to: string) => {
    setRegisterDateRange({ month, from, to })
  }, [month])

  const changeTagFilter = useCallback((tag: string | null) => {
    setTagFilter(tag)
    if (!tag) return
    if (view !== 'transactions') setTransactionDateScope('month')
    setImportMode(null)
    changeView('transactions')
  }, [changeView, view])

  const openRecurringRules = useCallback((recurringRuleId: string) => {
    if (ledgerInteractionLocked) return
    setImportMode(null)
    setRecurringTransferRuleFocusId(null)
    setRecurringRuleFocusId(recurringRuleId)
    changeView('recurring')
  }, [changeView, ledgerInteractionLocked])

  const openRecurringTransferRules = useCallback((recurringTransferRuleId: string) => {
    if (ledgerInteractionLocked) return
    setImportMode(null)
    setRecurringRuleFocusId(null)
    setRecurringTransferRuleFocusId(recurringTransferRuleId)
    changeView('recurring')
  }, [changeView, ledgerInteractionLocked])

  const handleLedgerRestored = useCallback(async () => {
    setSavedTransactionViews([])
    const savedViewsCleared = forgetSavedTransactionViews(() => window.localStorage)
    const refreshed = await refreshMoneyData('error')
    setLedgerGeneration((generation) => generation + 1)
    return { refreshed, savedViewsCleared }
  }, [refreshMoneyData])

  const storeSavedTransactionViews = useCallback(
    (update: (current: SavedTransactionView[]) => SavedTransactionView[]) => {
      setSavedTransactionViews((current) => {
        const next = update(current)
        try {
          window.localStorage.setItem(
            SAVED_TRANSACTION_VIEWS_STORAGE_KEY,
            serializeSavedTransactionViews(next),
          )
        } catch {
          // The saved view remains available for this tab when browser storage is unavailable.
        }
        return next
      })
    },
    [],
  )

  const saveTransactionView = useCallback((name: string) => {
    const candidate: SavedTransactionView = {
      id: crypto.randomUUID(),
      name,
      scope: transactionDateScope,
      dateFrom: transactionDateScope === 'range' ? transactionDateRange.from : null,
      dateTo: transactionDateScope === 'range' ? transactionDateRange.to : null,
      type: filter,
      status: clearingFilter,
      importReviewStatus: importReviewFilter,
      accountId: accountFilterId,
      categoryId: categoryFilterId,
      payee: payeeFilter,
      search: search.trim(),
      amountMinor: amountFilterMinor,
      tag: tagFilter,
      duplicates: duplicatesOnly,
      sort: transactionSort,
    }
    storeSavedTransactionViews((current) => addSavedTransactionView(current, candidate).views)
  }, [accountFilterId, amountFilterMinor, categoryFilterId, clearingFilter, duplicatesOnly, filter, importReviewFilter, payeeFilter, search, storeSavedTransactionViews, tagFilter, transactionDateRange.from, transactionDateRange.to, transactionDateScope, transactionSort])

  const applySavedTransactionView = useCallback((savedView: SavedTransactionView) => {
    const accountId = savedView.accountId !== null
      && data.accounts.some(({ id }) => id === savedView.accountId)
      ? savedView.accountId
      : null
    const category = savedView.categoryId === null
      ? undefined
      : data.categories.find(({ id }) => id === savedView.categoryId)
    const categoryId = category && (savedView.type === 'all' || category.type === savedView.type)
      ? category.id
      : null
    setFilter(savedView.type)
    setTransactionDateScope(savedView.scope)
    if (savedView.scope === 'range' && savedView.dateFrom && savedView.dateTo) {
      setCustomTransactionDateRange({ from: savedView.dateFrom, to: savedView.dateTo })
    }
    setClearingFilter(savedView.status)
    setImportReviewFilter(savedView.importReviewStatus)
    setAccountFilterId(accountId)
    setCategoryFilterId(categoryId)
    setPayeeFilter(savedView.payee)
    setSearch(savedView.search)
    setAmountFilterMinor(savedView.amountMinor)
    setTagFilter(savedView.tag)
    setDuplicatesOnly(savedView.duplicates)
    setTransactionSort(savedView.sort)
    setImportMode(null)
    setRegisterAccountId(null)
  }, [data.accounts, data.categories])

  const resetTransactionFilters = useCallback(() => {
    setFilter('all')
    setTransactionDateScope('month')
    setClearingFilter('all')
    setImportReviewFilter('all')
    setAccountFilterId(null)
    setCategoryFilterId(null)
    setPayeeFilter(null)
    setSearch('')
    setAmountFilterMinor(null)
    setTagFilter(null)
    setDuplicatesOnly(false)
    setTransactionSort('date_desc')
    setCustomTransactionDateRange(null)
    setImportMode(null)
    setRegisterAccountId(null)
  }, [])

  const openImportedTransactionReview = useCallback((
    reviewStatus: 'unreviewed' | 'needs_follow_up',
  ) => {
    resetTransactionFilters()
    setImportMode(null)
    setTransactionDateScope('all')
    setImportReviewFilter(reviewStatus)
    changeView('transactions')
    requestAnimationFrame(() => transactionsPanelRef.current?.focus())
  }, [changeView, resetTransactionFilters])

  const applyAiCopilotAction = useCallback((action: AiCopilotAction) => {
    if (ledgerInteractionLocked) return
    if (!aiCopilotActionIsCurrent(action, data.accounts, data.categories)) {
      setAiCopilotActionStale(true)
      return
    }
    setAiCopilotActionStale(false)

    if (action.type === 'show_transactions') {
      resetTransactionFilters()
      setFilter(action.filters.transactionType)
      setCategoryFilterId(action.filters.categoryId)
      setImportReviewFilter(action.filters.importReviewStatus)
      setDuplicatesOnly(action.filters.duplicatesOnly)
      setSearch(action.filters.search ?? '')
      changeView('transactions')
      return
    }

    if (action.type === 'show_overview') {
      setImportMode(null)
      setOverviewReview(action.review)
      changeView('overview')
      return
    }

    if (action.type === 'open_recurring') {
      setImportMode(null)
      setRecurringRuleFocusId(null)
      setRecurringTransferRuleFocusId(null)
      changeView('recurring')
      return
    }

    if (action.type === 'open_ai_import') {
      openImport('statement')
      return
    }

    clearActionMessage()
    setImportMode(null)
    if (action.type === 'draft_transaction') {
      setEditingTransaction(null)
      setTransactionDraft(action.input)
      setTransactionDraftKind('ai')
      setDialogOpen(true)
      return
    }

    setRecurringRuleFocusId(null)
    setRecurringTransferRuleFocusId(null)
    setRecurringDraft({ ...action.input, isActive: false })
    setRecurringDraftKind('ai')
    changeView('recurring')
  }, [
    changeView,
    clearActionMessage,
    data.accounts,
    data.categories,
    ledgerInteractionLocked,
    openImport,
    resetTransactionFilters,
  ])

  const openSummaryTransactions = useCallback((nextFilter: TransactionFilter) => {
    if (ledgerInteractionLocked) return
    resetTransactionFilters()
    setFilter(nextFilter)
    changeView('transactions')
  }, [changeView, ledgerInteractionLocked, resetTransactionFilters])

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      try {
        setSavedTransactionViews(parseSavedTransactionViews(
          window.localStorage.getItem(SAVED_TRANSACTION_VIEWS_STORAGE_KEY),
        ))
      } catch {
        // Saved views are optional when browser storage is unavailable.
      }
    }, 0)
    const syncSavedTransactionViews = (event: StorageEvent) => {
      let localStorage: Storage
      try {
        localStorage = window.localStorage
      } catch {
        return
      }
      if (event.storageArea !== localStorage) return
      setSavedTransactionViews((current) => applySavedTransactionViewsStorageChange(
        current,
        event.key,
        event.newValue,
      ))
    }
    window.addEventListener('storage', syncSavedTransactionViews)
    return () => {
      window.clearTimeout(timeout)
      window.removeEventListener('storage', syncSavedTransactionViews)
    }
  }, [])

  useEffect(() => {
    if (initialViewRef.current) {
      initialViewRef.current = false
      return
    }
    mainRef.current?.focus({ preventScroll: true })
  }, [view])

  useEffect(() => {
    if (view !== 'transactions' || !importMode) return
    const target = importMode === 'statement' && aiStatementImportConfigured
      ? importPanelRef.current?.querySelector<HTMLTextAreaElement>('textarea')
      : importPanelRef.current
    target?.focus()
  }, [aiStatementImportConfigured, importMode, view])

  useEffect(() => {
    if (
      data.transactionPageLoadedMore
      && !data.transactionPageHasMore
      && !data.transactionPageLoading
    ) {
      transactionLoadStatusRef.current?.focus({ preventScroll: true })
    }
  }, [
    data.transactionPageHasMore,
    data.transactionPageLoadedMore,
    data.transactionPageLoading,
  ])

  const viewTitle =
    view === 'overview'
      ? t('overview')
      : view === 'transactions'
        ? t('transactions')
        : view === 'recurring'
          ? t('recurring')
          : t('settings')

  const transactions = view === 'overview' ? data.transactions.slice(0, 5) : data.transactions
  const loading = data.source === 'loading' || data.reportMonth !== month
  const moneyView = view === 'overview' || view === 'transactions'
  const transactionCountLabel = loading
    ? t('loadingTransactionCount')
    : data.transactionFilterSummary.transactionCount > data.transactions.length
      ? t('limitedTransactionCount', {
          visible: data.transactions.length,
          total: data.transactionFilterSummary.transactionCount,
        })
      : t('transactionCount', { count: data.transactionFilterSummary.transactionCount })
  const overviewTransactionFiltersActive = filter !== 'all'
    || clearingFilter !== 'all'
    || importReviewFilter !== 'all'
    || accountFilterId !== null
    || categoryFilterId !== null
    || payeeFilter !== null
    || search.trim().length > 0
    || amountFilterMinor !== null
    || tagFilter !== null
    || duplicatesOnly
  const transactionLoadMoreCount = Math.min(
    TRANSACTION_PAGE_SIZE,
    Math.max(0, data.transactionFilterSummary.transactionCount - data.transactions.length),
  )

  return (
    <div className="app-shell">
      <AppHeader
        view={view}
        navigationDisabled={ledgerInteractionLocked}
        addDisabled={transactionEntryDisabled}
        aiStatementImportConfigured={aiStatementImportConfigured}
        aiStatementImportOpen={view === 'transactions' && importMode === 'statement'}
        onAdd={openDialog}
        onAiStatementImport={(trigger) => openImport('statement', trigger)}
        onViewChange={changeView}
      />
      <main
        className={`app-main view-${view}`}
        ref={mainRef}
        tabIndex={-1}
        aria-labelledby="app-view-title"
        aria-busy={ledgerInteractionLocked || undefined}
      >
        <h1 className="sr-only" id="app-view-title">{viewTitle}</h1>
        <div hidden={!moneyView}>
          <ConnectionBanner
            source={data.source}
            online={data.online}
            actionMessage={data.actionMessage}
            onRetry={data.source === 'demo' ? undefined : () => void data.refresh()}
          />
          <MonthNavigator
            month={month}
            currentMonth={initialMonth}
            disabled={ledgerInteractionLocked}
            onChange={setMonth}
            onPrevious={() => setMonth((value) => shiftMonth(value, -1))}
            onNext={() => setMonth((value) => shiftMonth(value, 1))}
          />
          <div className="overview-region">
            <SummaryCards
              summary={data.summary}
              loading={loading}
              disabled={ledgerInteractionLocked}
              onSelect={openSummaryTransactions}
            />
            {view === 'overview' ? (
              <>
                <LedgerBackupReminder
                  due={ledgerBackupDue}
                  live={data.source === 'live'}
                  disabled={ledgerInteractionLocked}
                  onReview={() => openSettings('data')}
                />
                <AccountBalances
                  balances={data.accountBalances}
                  month={month}
                  loading={loading}
                  canReconcile={data.source === 'live' && data.online}
                  onReview={openAccountTransactions}
                  onCompare={openAccountReconciliation}
                />
                <EmergencyFundProgress
                  goal={data.emergencyFundGoal}
                  balance={!loading && data.emergencyFundGoal
                    ? data.accountBalances.find(
                      ({ accountId }) => accountId === data.emergencyFundGoal?.accountId,
                    ) ?? null
                    : null}
                  month={month}
                  loading={loading}
                  canManage={data.source === 'live' && data.online}
                  onManage={() => openSettings('ledger')}
                />
                <OverviewMonthlyReview
                  selected={overviewReview}
                  onChange={setOverviewReview}
                  content={{
                    netWorth: (
                      <NetWorthTrend
                        points={data.netWorthTrend}
                        month={month}
                        loading={loading}
                        onSelectMonth={setMonth}
                      />
                    ),
                    cashFlow: (
                      <CashFlowTrend
                        summary={data.summary}
                        currentMonth={scheduledOutlookToday.slice(0, 7)}
                        loading={loading}
                        onSelectMonth={setMonth}
                      />
                    ),
                    income: (
                      <IncomeSources
                        summary={data.summary}
                        loading={loading}
                        onSelect={openCategoryTransactions}
                      />
                    ),
                    spending: (
                      <CategorySpending
                        summary={data.summary}
                        loading={loading}
                        onSelectCategory={openCategoryTransactions}
                        onSelectPayee={openPayeeTransactions}
                      />
                    ),
                    plans: (
                      <MonthlySpendingPlans
                        summary={data.summary}
                        loading={loading}
                        onSelect={openCategoryTransactions}
                      />
                    ),
                    outlook: (
                      <RecurringForecast
                        key={month}
                        summary={data.summary}
                        accounts={data.accounts}
                        categories={data.categories}
                        loading={loading}
                        onManage={openRecurringRules}
                        onManageTransfer={openRecurringTransferRules}
                      />
                    ),
                  }}
                />
              </>
            ) : null}
          </div>

          <section
            className="transactions-panel"
            ref={transactionsPanelRef}
            tabIndex={-1}
            aria-labelledby={registerAccountId === null ? 'transactions-title' : undefined}
            aria-label={registerAccountId !== null ? t('accountRegisterList') : undefined}
          >
            {registerAccountId === null ? <div className="transactions-heading">
              <div>
                <h2 id="transactions-title">{t('transactionRecords')}</h2>
                <p>{transactionCountLabel}</p>
              </div>
              <button
                className="view-all-button"
                type="button"
                disabled={ledgerInteractionLocked}
                onClick={() => openSummaryTransactions('all')}
              >
                {t('monthTransactions')}
                <ChevronRight aria-hidden="true" />
              </button>
              <TransactionToolbar
                search={search}
                amountFilterMinor={amountFilterMinor}
                payeeFilter={payeeFilter}
                tagFilter={tagFilter}
                filter={filter}
                clearingFilter={clearingFilter}
                importReviewFilter={importReviewFilter}
                dateScope={transactionDateScope}
                dateFrom={transactionDateRange.from}
                dateTo={transactionDateRange.to}
                duplicatesOnly={duplicatesOnly}
                sort={transactionSort}
                showSort={view === 'transactions'}
                month={month}
                currentDate={initialDate}
                accounts={data.accounts}
                categories={data.categories}
                accountFilterId={accountFilterId}
                categoryFilterId={categoryFilterId}
                canExport={data.source === 'live' && data.online}
                canImport={data.source === 'live' && data.online}
                onSearchChange={setSearch}
                onAmountFilterChange={setAmountFilterMinor}
                onPayeeFilterChange={setPayeeFilter}
                onTagFilterChange={changeTagFilter}
                onFilterChange={changeTransactionFilter}
                onClearingFilterChange={setClearingFilter}
                onImportReviewFilterChange={setImportReviewFilter}
                onDateScopeChange={setTransactionDateScope}
                onDateFromChange={changeTransactionDateFrom}
                onDateToChange={changeTransactionDateTo}
                onDuplicatesOnlyChange={setDuplicatesOnly}
                onSortChange={setTransactionSort}
                onAccountFilterChange={setAccountFilterId}
                onCategoryFilterChange={setCategoryFilterId}
                onClearReferenceFilters={clearReferenceFilters}
                onCsvImport={() => openImport('csv')}
                onAiStatementImport={() => openImport('statement')}
                onAiCopilot={() => openImport('copilot')}
                csvImportOpen={importMode === 'csv'}
                aiStatementImportOpen={importMode === 'statement'}
                aiCopilotOpen={importMode === 'copilot'}
                csvImportButtonRef={csvImportButtonRef}
                aiStatementImportButtonRef={aiStatementImportButtonRef}
                aiCopilotButtonRef={aiCopilotButtonRef}
              />
              {view === 'overview' && overviewTransactionFiltersActive ? (
                <div className="transaction-preview-filter-notice">
                  <p>{t('overviewTransactionFiltersActive')}</p>
                  <button
                    className="button button-secondary"
                    type="button"
                    onClick={() => changeView('transactions')}
                  >
                    {t('reviewTransactionFilters')}
                  </button>
                </div>
              ) : null}
              {view === 'transactions' ? (
                <>
                  <TransactionFilterSummary
                    summary={data.transactionFilterSummary}
                    loading={loading}
                  />
                  <SavedTransactionViews
                    views={savedTransactionViews}
                    accounts={data.accounts}
                    categories={data.categories}
                    canSave={
                      filter !== 'all'
                      || transactionDateScope !== 'month'
                      || clearingFilter !== 'all'
                      || importReviewFilter !== 'all'
                      || accountFilterId !== null
                      || categoryFilterId !== null
                      || payeeFilter !== null
                      || search.trim().length > 0
                      || amountFilterMinor !== null
                      || tagFilter !== null
                      || duplicatesOnly
                      || transactionSort !== 'date_desc'
                    }
                    onSave={saveTransactionView}
                    onApply={applySavedTransactionView}
                    onDelete={(id) => storeSavedTransactionViews(
                      (current) => current.filter((view) => view.id !== id),
                    )}
                    onReset={resetTransactionFilters}
                  />
                </>
              ) : null}
            </div> : null}
            {registerAccountId === null && view === 'transactions' && importMode === 'csv' ? (
              <CsvImportPanel
                key={`csv-import-${data.ledgerSettings.updatedAt}`}
                accounts={data.accounts}
                categories={data.categories}
                available={data.source === 'live' && data.online}
                panelRef={importPanelRef}
                onClose={closeImport}
                onImported={() => data.refresh('error')}
                onReviewImports={openImportedTransactionReview}
                onMutationStateChange={setImportMutationInProgress}
              />
            ) : null}
            {registerAccountId === null && view === 'transactions' && importMode === 'copilot' ? (
              <>
                {aiCopilotActionStale ? (
                  <div className="status-banner status-warning" role="alert">
                    <span>{t('aiCopilotActionStale')}</span>
                  </div>
                ) : null}
                <AiCopilotPanel
                  key={`ai-copilot-${month}`}
                  month={month}
                  settings={aiSettings}
                  persistedSettings={aiSettingsRow}
                  settingsConflict={aiSettingsConflict}
                  persistedSettingsAvailable={data.aiProviderSettingsStatus === 'ready'}
                  available={data.source === 'live' && data.online}
                  panelRef={importPanelRef}
                  onClose={closeImport}
                  onConfigure={() => openSettings('connections')}
                  onOpenAiImport={() => openImport('statement')}
                  onAction={applyAiCopilotAction}
                />
              </>
            ) : null}
            {registerAccountId === null && view === 'transactions' && importMode === 'statement' ? (
              <BankImportPanel
                key={`statement-import-${data.ledgerSettings.updatedAt}`}
                settings={aiSettings}
                persistedSettings={aiSettingsRow}
                settingsConflict={aiSettingsConflict}
                persistedSettingsAvailable={data.aiProviderSettingsStatus === 'ready'}
                accounts={data.accounts}
                categories={data.categories}
                available={data.source === 'live' && data.online}
                panelRef={importPanelRef}
                onClose={closeImport}
                onConfigure={() => openSettings('connections')}
                onImported={() => data.refresh('error')}
                onReviewImports={openImportedTransactionReview}
                onReconcile={openImportedStatementReconciliation}
                onMutationStateChange={setImportMutationInProgress}
              />
            ) : null}
            {view === 'transactions' && registerAccountId !== null ? (
              <AccountRegister
                key={`${registerAccountId}:${month}`}
                accountId={registerAccountId}
                currency={data.accounts.find((account) => account.id === registerAccountId)?.currency
                  ?? data.ledgerSettings.currency}
                register={data.accountRegister}
                canExport={data.source === 'live' && data.online}
                snapshotVersion={data.snapshotVersion}
                dateFrom={effectiveRegisterDateRange.from}
                dateTo={effectiveRegisterDateRange.to}
                transactions={data.transactions}
                transfers={data.accountTransfers}
                loading={loading}
                saving={ledgerInteractionLocked}
                reconcileInitially={registerMode === 'reconcile'}
                initialStatementBalanceMinor={registerStatementBalance?.month === month
                  ? registerStatementBalance.minor
                  : null}
                onClose={closeAccountRegister}
                onDateRangeChange={changeRegisterDateRange}
                onEditTransaction={openTransaction}
                onEditTransfer={openTransferDialog}
                onSetEntryCleared={setAccountRegisterEntryClearing}
              />
            ) : view === 'transactions' ? (
              <AccountTransferList
                transfers={data.accountTransfers}
                loading={loading}
                available={data.source === 'live' && data.online && data.accounts.filter(({ isActive }) => isActive).length >= 2}
                onAdd={() => openTransferDialog()}
                onEdit={openTransferDialog}
              />
            ) : null}
            {registerAccountId === null ? (
              <>
                <TransactionList
                  key={[
                    month,
                    transactionDateScope,
                    transactionDateRange.from,
                    transactionDateRange.to,
                    view,
                    filter,
                    clearingFilter,
                    importReviewFilter,
                    accountFilterId,
                    categoryFilterId,
                    payeeFilter,
                    amountFilterMinor,
                    deferredSearch,
                    tagFilter,
                    duplicatesOnly,
                    transactionSort,
                    data.snapshotVersion,
                  ].join('|')}
                  transactions={transactions}
                  categories={data.categories}
                  loading={loading}
                  tagFilter={tagFilter}
                  duplicateReview={duplicatesOnly}
                  allowBulkActions={view === 'transactions'}
                  saving={data.saving}
                  onEdit={openTransaction}
                  onTagSelect={changeTagFilter}
                  onSetCategory={setSelectedTransactionsCategory}
                  onSetClearing={setSelectedTransactionsClearing}
                  onSetImportReviewStatus={setSelectedTransactionsImportReviewStatus}
                />
                {view === 'transactions' && (
                  data.transactionPageHasMore
                  || data.transactionPageLoading
                  || data.transactionPageError
                  || data.transactionPageLoadedMore
                  || data.transactionPageRefreshRequired
                ) ? (
                  <div className="transaction-load-more" aria-live="polite">
                    {data.transactionPageHasMore ? (
                      <button
                        className="button button-secondary"
                        type="button"
                        disabled={ledgerInteractionLocked || data.transactionPageLoading}
                        onClick={() => void data.loadMoreTransactions()}
                      >
                        {t(data.transactionPageLoading
                          ? 'loadingMoreTransactions'
                          : 'loadMoreTransactions', { count: transactionLoadMoreCount })}
                      </button>
                    ) : null}
                    {data.transactionPageRefreshRequired ? (
                      <button
                        className="button button-secondary"
                        type="button"
                        disabled={ledgerInteractionLocked || data.transactionPageLoading}
                        onClick={() => void data.retryTransactionPageRefresh()}
                      >
                        {t('retry')}
                      </button>
                    ) : null}
                    {data.transactionPageError ? (
                      <p role="status">{data.transactionPageError}</p>
                    ) : !data.transactionPageHasMore && data.transactionPageLoadedMore ? (
                      <p ref={transactionLoadStatusRef} role="status" tabIndex={-1}>
                        {t('allMatchingTransactionsLoaded')}
                      </p>
                    ) : null}
                  </div>
                ) : null}
              </>
            ) : null}
          </section>
        </div>
        <div hidden={view !== 'recurring'}>
          <RecurringRulesPage
            key={ledgerGeneration}
            active={view === 'recurring'}
            accounts={data.accounts}
            categories={data.categories}
            draft={recurringDraft}
            draftKind={recurringDraftKind}
            focusRuleId={recurringRuleFocusId}
            focusTransferRuleId={recurringTransferRuleFocusId}
            ledgerContext={data.ledgerSettings.updatedAt}
            ledgerSource={data.source}
            mutable={data.source === 'live' && data.online}
            onMoneyRefresh={data.refresh}
            onDraftClose={closeRecurringDraft}
            onFocusRuleHandled={clearRecurringRuleFocus}
            onFocusTransferRuleHandled={clearRecurringTransferRuleFocus}
            onMutationStateChange={setRecurringMutationInProgress}
          />
        </div>
        <div hidden={view !== 'settings'}>
          <SettingsPage
            activeCategory={settingsCategory}
            onCategoryChange={setSettingsCategory}
            aiSettings={aiSettings}
            onAiSettingsChange={changeAiSettings}
            aiSettingsRow={aiSettingsRow}
            aiSettingsConflict={aiSettingsConflict}
            aiSettingsPersistenceStatus={data.aiProviderSettingsStatus}
            onResetAiSettings={() => setAiSettingsDraft(null)}
            onReloadAiSettings={() => data.refresh('preserve')}
            onSaveAiSettings={saveAiSettings}
            onDeleteAiSettings={deleteAiSettings}
            accounts={data.accounts}
            categories={data.categories}
            emergencyFundGoal={data.emergencyFundGoal}
            ledgerSettings={data.ledgerSettings}
            canManageReferences={data.source === 'live' && data.online}
            ledgerRestoreInProgress={ledgerRestoreInProgress}
            otherLedgerMutationInProgress={otherLedgerMutationInProgress}
            onBackupDueChange={setLedgerBackupDue}
            onReferenceRefresh={() => data.refresh('error')}
            onLedgerRestored={handleLedgerRestored}
            onLedgerMutationStateChange={setSettingsMutationInProgress}
            onLedgerRestoreStateChange={changeLedgerRestoreState}
          />
        </div>
      </main>

      <MobileNavigation
        view={view}
        disabled={ledgerInteractionLocked}
        addDisabled={transactionEntryDisabled}
        onChange={changeView}
        onAdd={openDialog}
      />
      {dialogOpen ? (
        <TransactionDialog
          key={`${ledgerGeneration}:${editingTransaction ? `edit:${editingTransaction.id}` : transactionDraft ? `${transactionDraftKind ?? 'duplicate'}:${transactionDraft.id}` : 'new'}`}
          accounts={data.accounts}
          categories={data.categories}
          ledgerContext={data.ledgerSettings.updatedAt}
          saving={data.saving}
          serverError={data.saveError}
          online={data.online}
          source={data.source}
          transaction={editingTransaction}
          draft={transactionDraft}
          draftKind={transactionDraftKind}
          onClose={closeDialog}
          onSubmit={saveTransaction}
          onDelete={removeTransaction}
          onDuplicate={duplicateTransaction}
          onMakeRecurring={makeTransactionRecurring}
        />
      ) : null}
      {transferDialogOpen ? (
        <AccountTransferDialog
          key={`${ledgerGeneration}:${editingTransfer ? `transfer:${editingTransfer.id}` : 'new-transfer'}`}
          accounts={data.accounts}
          ledgerContext={data.ledgerSettings.updatedAt}
          saving={data.saving}
          serverError={data.saveError}
          online={data.online}
          available={data.source === 'live' && data.online}
          transfer={editingTransfer}
          onClose={closeTransferDialog}
          onSubmit={saveTransfer}
          onDelete={removeAccountTransfer}
        />
      ) : null}
    </div>
  )
}

export default App
